import { onAuthStateChanged } from "firebase/auth";
import { getDoc, getDocs, onSnapshot } from "firebase/firestore";
import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useState,
} from "react"; // =================================================================================
import { auth, colRef, docReference } from "../utils/services";
import { onRemoveFromCart } from "../utils/cart";
// import CommerceSDK from "@chec/commerce.js";

// export const client = new CommerceSDK(process.env.NEXT_PUBLIC_CHEC_PUBLIC_API_KEY);

// =================================================================================
const initialState = {
  cart: [
    {
      price: 250,
      name: "Ford 2019",
      imgUrl: "/assets/images/products/Automotive/1.Ford2019.png",
      id: "7222243834583537",
      qty: 1,
    },
    {
      price: 250,
      name: "Porsche 2020",
      imgUrl: "/assets/images/products/Automotive/28.Porsche2020.png",
      id: "38553442244076086",
      qty: 1,
    },
    {
      price: 250,
      name: "Heavy 20kt Gold Necklace",
      imgUrl:
        "/assets/images/products/Fashion/Jewellery/9.Heavy20ktGoldNecklace.png",
      id: "9573201630529315",
      qty: 1,
    },
  ],
};
const AppContext = createContext({
  state: initialState,
  dispatch: () => {},
  uid: null,
  userData: null,
});

const reducer = (state, action) => {
  switch (action.type) {
    case "CHANGE_CART_AMOUNT":
      let cartList = state.cart;
      let cartItem = action.payload;
      let exist = cartList.find((item) => item.id === cartItem.id);

      // IF PRODUCT QUANTITY IS LESS THAN 1 remove it from cart
      if (cartItem.qty < 1) {
        const filteredCart = cartList.filter((item) => item.id !== cartItem.id);
        return { ...state, cart: filteredCart };
      }

      // IF PRODUCT ALREADY EXITS IN CART UPDATE THE QUANTITY
      if (exist) {
        const newCart = cartList.map((item) =>
          item.id === cartItem.id ? { ...item, qty: cartItem.qty } : item
        );
        return { ...state, cart: newCart };
      }

      return { ...state, cart: [...cartList, cartItem] };

    default: {
      return state;
    }
  }
};

const cartDataList = [];

const cartReducer = (state, action) => {
  switch (action.type) {
    case "ADD_TO_CART":
      let cartList = [...state];
      let cartItem = action.payload;
      let exist = cartList.find((item) => item.ref.id === cartItem.ref.id);

      // IF PRODUCT ALREADY EXITS IN CART UPDATE THE QUANTITY
      if (exist) {
        const newCart = cartList.map((item) =>
          item.ref.id === cartItem.ref.id
            ? { ...item, qty: item.qty + cartItem.qty }
            : item
        );
        return [...newCart];
      }

      return [...cartList, cartItem];

    case "REMOVE_FROM_CART":
      let cartData = [...state];
      let item = action.payload;
      const filteredCart = cartData.filter(
        (item) => item.ref.id !== item.ref.id
      );
      onRemoveFromCart(item);
      return [...filteredCart];

    case "initializeCart":
      let cart = action.payload;
      return [...cart];
  }
};

export const AppProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [uid, setUid] = React.useState(null);
  const [userData, setUserData] = React.useState(null);
  const [cartData, cartDispatch] = useReducer(cartReducer, cartDataList);
  const [cartItemtotal, setCartItemTotal] = React.useState(null);
  const [cartItem, setCartItem] = useState(null);
  const [wishList, setWishList] = React.useState([]);

  const [token, setToken] = useState(
    typeof window !== "undefined" ? sessionStorage.getItem("token") : ""
  );

  useEffect(() => {
    return onAuthStateChanged(auth, (user) => {
      if (user) {
        setUid(user.uid);
      } else {
        setUid(null);
      }
    });
  }, []);

  useEffect(() => {
    if (!sessionStorage.getItem("token")) {
      let anonymous_token =
        Math.random().toString(36).substring(2, 15) +
        Math.random().toString(36).substring(2, 15);
      setToken(anonymous_token);
      localStorage.setItem("anonymous_token", anonymous_token);
    }
  }, []);

  useEffect(() => {
    // @TODO Will add option to show the cart with localStorage later.
    if (typeof window !== "undefined") {
      let cartData = localStorage.getItem("sutan-cart");
      console.log("cartData", cartData);
      cartData = null !== cartData ? JSON.parse(cartData) : "";
    }
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const handleStorageEvent = (e) => {
        if (e.key === "token") {
          setToken(sessionStorage.getItem("token"));
        } else {
          setToken(localStorage.getItem("anonymous_token"));
        }
      };
      window.addEventListener("storage", handleStorageEvent);
      return () => {
        window.removeEventListener("storage", handleStorageEvent);
      };
    }
  }, []);
  // console.log("token", token);

  useEffect(() => {
    if (uid) {
      const ref = docReference(`users/${uid}`);
      const unsubscribe = onSnapshot(ref, (doc) => {
        if (doc.exists()) {
          setUserData({ ...doc.data(), ref: doc.ref });
        } else {
          setUserData(null);
        }
      });

      const subCart = onSnapshot(
        colRef(`users/${uid}/cart`),
        (querySnapshot) => {
          const cart = [];
          querySnapshot.forEach((doc) => {
            cart.push({ ...doc.data(), cartRef: doc.ref });
          });

          cartDispatch({ type: "initializeCart", payload: cart });
        }
      );

      const subWishlist = onSnapshot(
        colRef(`users/${uid}/wishList`),
        (querySnapshot) => {
          const wishList = [];
          querySnapshot.forEach((doc) => {
            wishList.push({ ...doc.data(), wishListRef: doc.ref });
          });

          setWishList(wishList);
        }
      );

      return () => {
        unsubscribe;
        subCart;
        subWishlist;
      };
    }
  }, [uid]);

  // console.log("cartData", cartData);

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
        uid,
        userData,
        cartData,
        cartDispatch,
        cartItemtotal,
        setCartItemTotal,
        wishList,
        cartItem,
        setCartItem,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
export const useAppContext = () => useContext(AppContext);
export default AppContext;
