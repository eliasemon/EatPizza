/** @type {import('next').NextConfig} */

const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: [
      "firebasestorage.googleapis.com",
      "abdoulouakil.org/sutan",
      "sutanback.local",
    ],
  },
};

module.exports = nextConfig;
