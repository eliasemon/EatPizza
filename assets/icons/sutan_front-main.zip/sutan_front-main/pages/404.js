import Header from "../components/header";
import Footer from "../components/footer";
import { BlackButton } from "../components/buttons";
import { useRouter } from "next/router";

export default function NotFound() {
  const router = useRouter();
  return (
    <div>
      <Header />

      <section className="notFound">
        <h2 className="notFound__code">404</h2>
        <p className="notFound__desc">Page not found!</p>
        <BlackButton
          title="Go to Home"
          style={{ marginTop: "2rem", width: "25rem" }}
          onClick={() => router.replace("/")}
        />
      </section>

      <Footer />
    </div>
  );
}
