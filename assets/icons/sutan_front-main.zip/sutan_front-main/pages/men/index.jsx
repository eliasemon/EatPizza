import React from "react";
import ShopLayout from "../../components/layouts/shopLayout/ShopLayout";

const index = () => {
  return (
    <ShopLayout>
      <div>this is men page</div>
    </ShopLayout>
  );
};

export default index;
