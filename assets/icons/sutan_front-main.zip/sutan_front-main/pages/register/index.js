import Link from "next/link";

import Header from "../../components/header";
import Footer from "../../components/footer";
import SubHeader from "../../components/subHeader";
import Breadcrumbs from "../../components/breadcrumbs";
import { PrimaryButton, BlackOutlineButton } from "../../components/buttons";

import styles from "../../styles/Register.module.scss";
import { useContext, useState } from "react";
import { isEmail } from "../../utils/helpers";
import { onUserCreate } from "../../utils/users";
import AppContext from "../../context/AppContext";
import { onLogOut } from "../../utils/services";
import { useRouter } from "next/router";

export default function Checkout() {
  const { uid } = useContext(AppContext);
  const router = useRouter();
  console.log(uid);
  const [userData, setUserData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const onChange = (e) => {
    setUserData({ ...userData, [e.target.name]: e.target.value });
  };

  const checkValidity = () => {
    if (!isEmail(userData.email)) {
      alert("Please enter a valid email address");
      return false;
    }
    if (userData.password !== userData.confirmPassword) {
      console.log("Passwords do not match");
      return false;
    }
    if (userData.firstName === "") {
      console.log("First name is required");
      return false;
    }
    if (userData.lastName === "") {
      console.log("Last name is required");
      return false;
    }
    if (userData.email === "") {
      console.log("Email is required");
      return false;
    }
    if (userData.password === "") {
      console.log("Password is required");
      return false;
    }
    if (userData.confirmPassword === "") {
      console.log("Confirm password is required");
      return false;
    }
    return true;
  };

  const onSubmit = async () => {
    if (checkValidity()) {
      console.log("Form is valid");
      console.log(userData);
      // const user =
      await onUserCreate(userData);
      router.push("/");
    }
  };
  return (
    <div className={styles.container}>
      <Header />

      <Breadcrumbs>
        <Link href="/">Home</Link>
        <Link href="/">Account</Link>
      </Breadcrumbs>

      <SubHeader>
        Account <strong>Register</strong>
      </SubHeader>

      <section className={styles.register}>
        {!uid ? (
          <div className="form" style={{ width: "100%" }}>
            <h3 className="form__sectionTitle" style={{ marginTop: 0 }}>
              Register
            </h3>

            <div className="form__control">
              <label className="form__label">First Name</label>
              <input
                className="form__input"
                type="text"
                name="firstName"
                onChange={onChange}
              />
            </div>

            <div className="form__control">
              <label className="form__label">Last Name</label>
              <input
                className="form__input"
                type="text"
                name="lastName"
                onChange={onChange}
              />
            </div>

            <div className="form__control">
              <label className="form__label">Email</label>
              <input
                className="form__input"
                type="text"
                name="email"
                onChange={onChange}
              />
            </div>

            <div className="form__control">
              <label className="form__label">Password</label>
              <input
                className="form__input"
                type="password"
                name="password"
                onChange={onChange}
              />
            </div>
            <div className="form__control">
              <label className="form__label">confirmPassword</label>
              <input
                className="form__input"
                type="password"
                name="confirmPassword"
                onChange={onChange}
              />
            </div>

            <div className="form__control">
              Have an account?{" "}
              <Link href="/login" className="form__link">
                Login
              </Link>
            </div>

            <div className="flexRow" style={{ justifyContent: "flex-end" }}>
              <PrimaryButton
                title="Register"
                style={{ width: "24rem" }}
                onClick={onSubmit}
              />
            </div>
          </div>
        ) : (
          <div
            className="form"
            style={{
              width: "100%",
              textAlign: "center",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "column",
            }}
          >
            <h3 className="form__sectionTitle" style={{ marginTop: 0 }}>
              You are already logged in
            </h3>
            <BlackOutlineButton
              title="Log Out"
              style={{ width: "24rem" }}
              onClick={onLogOut}
            />
          </div>
        )}
      </section>

      <Footer />
    </div>
  );
}
