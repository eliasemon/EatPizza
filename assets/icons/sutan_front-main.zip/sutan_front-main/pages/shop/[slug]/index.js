import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";

import Header from "../../../components/header";
import Footer from "../../../components/footer";
import Breadcrumbs from "../../../components/breadcrumbs";
import ProductCard from "../../../components/productCard";
import ProductQuantity from "../../../components/productQuantity";
import { BlackButton } from "../../../components/buttons";

import styles from "../../../styles/Product.module.scss";
import { RightArrowIcon, LeftArrowIcon } from "../../../components/icons";
import availabilIco from "../../../public/icons/available-ico.svg";
import { client } from "../../../utils/Apollo/apollo";
import {
  GET_PRODUCTS_SLUGS,
  GET_PRODUCT_BY_SLUG,
} from "../../../utils/queries/products";
import { useQuery } from "@apollo/client";
import HTMLReactParser from "html-react-parser";

export default function Product({ product }) {
  const [productPic, setProductPic] = useState("pic01");
  const [productColor, setProductColor] = useState("color1");
  const [productVariant, setProductVariant] = useState({});
  const [selVariant, setSelVariant] = useState([]);
  const [selTab, setSelTab] = useState("description");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [hasVariants, setHasVariants] = useState(false);
  const [isSeletedVariantInStock, setIsSeletedVariantInStock] = useState(false);
  // const [canAddToCart, setCanAddToCart] = useState(false);
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [requiredAttributes, setRequiredAttributes] = useState([]);

  const stockStatus = product?.stockStatus === "IN_STOCK";

  const allImages = [product?.image, ...product?.galleryImages?.nodes];

  useEffect(() => {
    if (hasVariants) {
      const result = product?.variations?.nodes.filter((variation) => {
        return selVariant.every((attribute) => {
          return variation.attributes.nodes.some((variationAttribute) => {
            return (
              attribute.label.toLowerCase() ===
                variationAttribute.label.toLowerCase() &&
              attribute.value.toLowerCase() ===
                variationAttribute.value.toLowerCase()
            );
          });
        });
      });
      setSelectedVariant(result);
    }

    // get the selected variant based on productVariant
  }, [selVariant, productVariant]);

  const renderUniqueVariants = useMemo(() => {
    const uniqueAttributes = new Set();
    product?.variations?.nodes?.forEach((variation) => {
      variation.attributes.nodes.forEach((attribute) => {
        uniqueAttributes.add(attribute.label);
      });
    });

    if (uniqueAttributes?.size > 0) {
      setHasVariants(true);
    }

    setRequiredAttributes(uniqueAttributes);

    // use the unique set of attributes to render the attributes
    const attributes = product?.attributes?.nodes.filter((attribute) =>
      uniqueAttributes.has(attribute.name)
    );

    return attributes || [];
  }, [product]);

  const addVariant = (attribute) => {
    // check if attribut label is already in selVariant array
    // if yes, replace it with the new attribute
    // if no, add it to the array
    const isAttributeInArray = selVariant.find(
      (variant) => variant.label === attribute.label
    );

    if (isAttributeInArray) {
      const newSelVariant = selVariant.map((variant) => {
        if (variant.label === attribute.label) {
          return attribute;
        } else {
          return variant;
        }
      });

      setSelVariant(newSelVariant);
    } else {
      setSelVariant([...selVariant, attribute]);
    }
  };

  const renderAttributes = () => {
    return renderUniqueVariants?.map((attribute) => {
      return (
        <div
          className={styles.product__attributes__attribute}
          key={attribute.id}
        >
          <h3 className={styles.product__attributes__attribute__title}>
            {attribute.name}
          </h3>
          <div className={styles.product__attributes__attribute__options}>
            {attribute?.options?.map((option) => {
              return (
                <div
                  className={
                    styles.product__attributes__attribute__options__option
                  }
                  key={option}
                >
                  <input
                    type="radio"
                    name={attribute.name}
                    id={option}
                    value={option}
                    // checked={productColor === option}
                    checked={productVariant[attribute.name] === option}
                    onChange={() => {
                      setProductVariant({
                        ...productVariant,
                        [attribute.name]: option,
                      });
                      addVariant({ label: attribute.name, value: option });
                    }}
                  />
                  <label htmlFor={option}>{option}</label>
                </div>
              );
            })}
          </div>
        </div>
      );
    });
  };

  const canAddToCart = useMemo(() => {
    if (hasVariants) {
      return (
        selectedVariant?.length === 1 &&
        selectedVariant?.[0]?.stockStatus === "IN_STOCK"
      );
    }
    return stockStatus;
  }, [hasVariants, selectedVariant, isSeletedVariantInStock, stockStatus]);

  const renderPrice = () => {
    if (product?.salePrice) {
      return product?.salePrice;
    } else {
      return product?.price;
    }
  };

  const onNextClick = () => {
    if (selectedIndex < allImages?.length - 1) {
      setSelectedIndex(selectedIndex + 1);
    }
  };

  const onPrevClick = () => {
    if (selectedIndex > 0) {
      setSelectedIndex(selectedIndex - 1);
    }
  };

  return (
    <div className={styles.container}>
      <Header />

      <Breadcrumbs>
        <Link href="/">Home</Link>
        <Link href="/shop">Shop</Link>
        <Link href={`/shop/${product.slug}`}>{product?.name}</Link>
      </Breadcrumbs>

      <section className={styles.product}>
        <div className={styles.product__slide}>
          <div className={styles.product__slide__container}>
            <div className={styles.product__slide}>
              <button className={styles.rightArrowBtn} onClick={onNextClick}>
                <RightArrowIcon fill="#000000" />
              </button>
              <button className={styles.leftArrowBtn} onClick={onPrevClick}>
                <LeftArrowIcon fill="#000000" />
              </button>
              <img
                className={styles.product__slide__img}
                src={allImages[selectedIndex]?.sourceUrl}
                alt={allImages[selectedIndex]?.altText}
              />

              <div
                className={styles.productThumbs}
                style={{
                  marginTop: 10,
                }}
              >
                {allImages?.map((image, index) => {
                  return (
                    <label
                      className={styles.productThumbs__item}
                      htmlFor={`pic-${index}`}
                      style={{
                        borderColor: selectedIndex === index && "#000000",
                      }}
                    >
                      <Image
                        src={image?.sourceUrl}
                        objectFit="cover"
                        width={56}
                        height={56}
                        style={{ borderRadius: 2 }}
                      />
                      <input
                        type="radio"
                        className={styles.productThumbs__item__input}
                        name="product_pic"
                        id={`pic-${index}`}
                        onChange={() => {
                          setSelectedIndex(index);
                        }}
                      />
                    </label>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        <div className={styles.product__detail}>
          <div className={styles.product__detail__container}>
            <h1 className={styles.productTitle}>{product?.name}</h1>
            {stockStatus ? (
              <div className={styles.availability} style={{ color: "#0F834D" }}>
                <Image
                  src={availabilIco}
                  alt="Availabil Ico"
                  width="14"
                  height="14"
                />
                <span style={{ marginLeft: 6 }}>In Stock</span>
              </div>
            ) : (
              <div className={styles.availability} style={{ color: "#FF0000" }}>
                <span style={{ marginLeft: 6 }}>Out of Stock</span>
              </div>
            )}

            <h2 className={styles.productPrice}>{renderPrice()}</h2>

            <div>{HTMLReactParser(product?.shortDescription ?? "")}</div>

            {renderAttributes()}

            <div className={styles.labelTitle}>Quantity:</div>

            <div className={styles.productQuantity}>
              <div style={{ marginBottom: 16 }}>
                <ProductQuantity quantity={1} />
              </div>

              <BlackButton
                title="Add to cart"
                style={{ width: 256 }}
                disabled={!canAddToCart}
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.details}>
        <div className={styles.details__container}>
          <nav className={styles.tabsNav}>
            <button
              className={styles.tabsNav__btn}
              style={{
                color: selTab === "description" && "#000000",
                borderBottomColor: selTab === "description" && "#AA2401",
              }}
              onClick={() => {
                setSelTab("description");
              }}
            >
              Product description
            </button>
            {/* <button
              className={styles.tabsNav__btn}
              style={{
                color: selTab === "reviews" && "#000000",
                borderBottomColor: selTab === "reviews" && "#AA2401",
              }}
              onClick={() => {
                setSelTab("reviews");
              }}
            >
              Product reviews
            </button> */}
          </nav>

          <div
            className={styles.tabsBody}
            style={{ display: selTab === "description" && "block" }}
          >
            <h3 className={styles.tabsBody__title}>{product.name}</h3>
            <div>{HTMLReactParser(product?.description ?? "")}</div>
          </div>

          {/* <div
            className={styles.tabsBody}
            style={{ display: selTab === "reviews" && "block" }}
          ></div> */}
        </div>
      </section>

      <div className="products">
        <h4 className="products__title">
          Similar <strong>Products</strong>
        </h4>
        <div className="products__container">
          {product?.related?.nodes?.map((prod) => {
            return <ProductCard key={prod.id} product={prod} />;
          })}
        </div>
      </div>

      <Footer />
    </div>
  );
}

// generate paths for dynamic routing (SSG)
export async function getStaticPaths() {
  const paths = await client.query({
    query: GET_PRODUCTS_SLUGS,
  });

  return {
    paths: paths.data.products.nodes.map(({ slug }) => ({
      params: { slug },
    })),
    fallback: false,
  };
}

// fetch data for each product (SSG)
export async function getStaticProps({ params }) {
  const { data } = await client.query({
    query: GET_PRODUCT_BY_SLUG,
    variables: {
      slug: params.slug,
    },
  });

  return {
    props: {
      product: data.product,
    },
  };
}
