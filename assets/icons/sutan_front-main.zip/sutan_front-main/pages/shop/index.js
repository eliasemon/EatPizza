import Link from "next/link";

import Header from "../../components/header";
import Footer from "../../components/footer";
import SubHeader from "../../components/subHeader";
import ProductCard from "../../components/productCard";
import Breadcrumbs from "../../components/breadcrumbs";
import Accordion from "../../components/accordion";

import styles from "../../styles/Shop.module.scss";
import ShopLayout from "../../components/layouts/shopLayout/ShopLayout";
import { client } from "../../utils/Apollo/apollo";
import { GET_PRODUCTS } from "../../utils/queries/products";

export default function Shop({ products }) {
  return (
    <ShopLayout>
      <section className={styles.productsContainer}>
        <div className={styles.productsContainer__container}>
          <div className={styles.productsContainer__products}>
            {products.map((product) => {
              return <ProductCard key={product.id} product={product} />;
            })}
          </div>
        </div>
      </section>
    </ShopLayout>
  );
}

// getStaticProps of all products in woocommerce store and pass it to the shop page
export async function getStaticProps() {
  const products = await client.query({ query: GET_PRODUCTS });

  return {
    props: {
      products: products.data.products.nodes,
    },
  };
}
