import Link from "next/link";

import Header from "../../components/header";
import Footer from "../../components/footer";
import SubHeader from "../../components/subHeader";
import Breadcrumbs from "../../components/breadcrumbs";
import { PrimaryButton } from "../../components/buttons";

import styles from "../../styles/Checkout.module.scss";
import { useContext, useState } from "react";
import { CountryDropdown, RegionDropdown } from "react-country-region-selector";
import LeftSidComponent from "../../components/checkout/LeftSidComponent";
import AppContext from "../../context/AppContext";
import CheckoutInfo from "../../components/checkout/CheckoutInfo";
import SpDialog from "../../components/SpDialog";
import { CircularProgress } from "@mui/material";

const defaultAddress = {
  fullName: "",
  address: "",
  city: "",
  country: "",
  region: "",
  zip: "",
};
export default function Checkout() {
  const {
    uid,
    cartData,
    cartItemtotal,
    setCartItemTotal,
    setCartItem,
    cartItem,
  } = useContext(AppContext);
  const [paying, setPaying] = useState(false);

  const getTotalPrice = () => {
    const totals = Object.values(cartItemtotal ?? {});
    return totals?.reduce((accum, price) => accum + price, 0);
  };

  return (
    <div className={styles.container}>
      <SpDialog open={paying} locked useCustomBox>
        <div className="modal-content w-96 p-16 bg-slate-300 z-50 rounded-sm flex justify-center items-center flex-col">
          <CircularProgress />
          <h3>We are processing your order</h3>
        </div>
      </SpDialog>
      <Header />

      <Breadcrumbs>
        <Link href="/">Home</Link>
        <Link href="/">Cart</Link>
        <Link href="/">Checout</Link>
      </Breadcrumbs>

      <SubHeader>
        <strong>Checkout</strong>
      </SubHeader>

      {!cartData?.length ? (
        <div className="h-96 w-full flex items-center justify-center">
          <h3 className="text-5xl">Cart is empty</h3>
        </div>
      ) : (
        <section className={styles.checkout}>
          <LeftSidComponent
            cartData={cartData}
            getTotal={getTotalPrice}
            setCartItem={setCartItem}
            cartItem={cartItem}
            setCartItemTotal={setCartItemTotal}
            uid={uid}
          />
          <CheckoutInfo
            cartData={cartData}
            getTotal={getTotalPrice}
            setCartItemTotal={setCartItemTotal}
            setCartItem={setCartItem}
            cartItem={cartItem}
          />
        </section>
      )}

      <Footer />
    </div>
  );
}
