import React from "react";
import ShopLayout from "../../components/layouts/shopLayout/ShopLayout";

const index = () => {
  return <ShopLayout>this is children page</ShopLayout>;
};

export default index;
