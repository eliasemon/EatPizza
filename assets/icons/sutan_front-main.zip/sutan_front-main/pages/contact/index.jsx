import React from "react";
import ShopLayout1 from "../../components/layouts/ShopLayout1";

const index = () => {
  return (
    <ShopLayout1>
      <div>this is contact page</div>
    </ShopLayout1>
  );
};

export default index;
