import React from "react";
import ShopLayout from "../../components/layouts/shopLayout/ShopLayout";

const index = () => {
  return (
    <ShopLayout>
      <div>this is women section</div>
    </ShopLayout>
  );
};

export default index;
