import { AppProvider } from "../context/AppContext";
import { ApolloProvider } from "@apollo/client";

import NextNProgress from "nextjs-progressbar";
import "simplebar/dist/simplebar.min.css";

import "../styles/globals.scss";
import MuiTheme from "../theme/MuiTheme";
import { client } from "../utils/Apollo/apollo";
import { useEffect } from "react";

function MyApp({ Component, pageProps }) {
  const AnyComponent = Component;

  const getLayout = AnyComponent.getLayout ?? ((page) => page);

  return (
    <ApolloProvider client={client}>
      <AppProvider>
        <MuiTheme>
          <NextNProgress color="#AA2401" />
          {getLayout(<AnyComponent {...pageProps} />)}
        </MuiTheme>
      </AppProvider>
    </ApolloProvider>
  );
}

export default MyApp;
