import Favorite from "@mui/icons-material/Favorite";
import { Button, Grid, Pagination } from "@mui/material";
import { FlexBox } from "../../../components/flex-box";

import SEO from "../../../components/SEO";
import CustomerDashboardLayout from "../../../components/layouts/customer-dashboard";
import UserDashboardHeader from "../../../components/UserDashboardHeader";
import CustomerDashboardNavigation from "../../../components/layouts/customer-dashboard/Navigations";
import ProductCard from "../../../components/productCard";

const productDatabase = [
  {
    price: 250,
    title: "Resla 2015",
    imgUrl: "/assets/images/products/Automotive/3.Tesla2015.png",
    category: "automotive",
    id: "1499483877456218",
  },

  {
    price: 250,
    title: "Xorsche 2018",
    imgUrl: "/assets/images/products/Automotive/4.Porsche2018.png",
    category: "automotive",
    id: "7645684541406523",
  },

  {
    price: 250,
    title: "Lord 2018",
    imgUrl: "/assets/images/products/Automotive/5.Ford2018.png",
    category: "automotive",
    id: "7388289389097056",
  },
];
const WishList = () => {
  return (
    <CustomerDashboardLayout>
      <SEO title="Wishlist" />
      <UserDashboardHeader
        icon={Favorite}
        title="My Wish List"
        navigation={<CustomerDashboardNavigation />}
        button={
          <Button
            color="primary"
            sx={{
              px: 4,
              bgcolor: "primary.light",
            }}
          >
            Add All to Cart
          </Button>
        }
      />

      <Grid container spacing={3}>
        {productDatabase.map((item) => (
          <Grid item lg={4} sm={6} xs={12} key={item.id}>
            <ProductCard
              title="Linen-blend Shirt"
              price="$15.00"
              prevPrice="$17.00"
              rating="5"
              totalRating="11"
              img="./../product_pic01.png"
            />
          </Grid>
        ))}
      </Grid>

      <FlexBox justifyContent="center" mt={5}>
        <Pagination
          count={5}
          color="primary"
          variant="outlined"
          onChange={(data) => console.log(data)}
        />
      </FlexBox>
    </CustomerDashboardLayout>
  );
};

export default WishList;
