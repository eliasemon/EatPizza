import Link from "next/link";
import Image from "next/image";

import Header from "../../components/header";
import Footer from "../../components/footer";
import SubHeader from "../../components/subHeader";
import Breadcrumbs from "../../components/breadcrumbs";
import { PrimaryButton, BlackOutlineButton } from "../../components/buttons";

import styles from "../../styles/Login.module.scss";
import { useContext, useState } from "react";
import { useRouter } from "next/router";
import AppContext from "../../context/AppContext";
import { onLogin, onLogOut } from "../../utils/services";
import { isEmail } from "../../utils/helpers";

export default function Checkout() {
  const router = useRouter();
  const { uid } = useContext(AppContext);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [userData, setUserData] = useState({
    email: "",
    password: "",
  });
  const onChange = (e) => {
    setUserData({ ...userData, [e.target.name]: e.target.value });
  };

  const checkValidity = () => {
    if (!isEmail(userData.email)) {
      alert("Please enter a valid email address");
      return false;
    }

    if (userData.email === "") {
      console.log("Email is required");
      return false;
    }
    if (userData.password === "") {
      console.log("Password is required");
      return false;
    }
    return true;
  };

  const onSubmit = async () => {
    if (checkValidity()) {
      await onLogin(userData.email, userData.password).catch((err) => {
        console.log(err);
      });
      router.replace("/");
    }
  };

  return (
    <div className={styles.container}>
      <Header />

      <Breadcrumbs>
        <Link href="/">Home</Link>
        <Link href="/">Account</Link>
      </Breadcrumbs>

      <SubHeader>
        Account <strong>Log In</strong>
      </SubHeader>

      <section className={styles.login}>
        {!uid ? (
          <>
            <div className={styles.login__left}>
              <div className={styles.login__left__container}>
                {isForgotPassword ? (
                  <div className="form">
                    <h3 className="form__sectionTitle" style={{ marginTop: 0 }}>
                      Login
                    </h3>

                    <div className="form__control">
                      <label className="form__label">Email</label>
                      <input
                        className="form__input"
                        type="email"
                        name="email"
                        onChange={onChange}
                      />
                    </div>

                    <div className="form__control">
                      <p
                        className="form__link"
                        onClick={() => setIsForgotPassword(false)}
                      >
                        Back to Login?
                      </p>
                    </div>

                    <div
                      className="flexRow"
                      style={{ justifyContent: "flex-end" }}
                    >
                      <PrimaryButton
                        title="Reset Password"
                        style={{ width: "24rem" }}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="form">
                    <h3 className="form__sectionTitle" style={{ marginTop: 0 }}>
                      Login
                    </h3>

                    <div className="form__control">
                      <label className="form__label">Email</label>
                      <input
                        className="form__input"
                        type="text"
                        name="email"
                        onChange={onChange}
                      />
                    </div>

                    <div className="form__control">
                      <label className="form__label">Password</label>
                      <input
                        className="form__input"
                        type="Password"
                        name="password"
                        onChange={onChange}
                      />
                    </div>

                    <div className="form__control">
                      <p
                        className="form__link"
                        onClick={() => setIsForgotPassword(true)}
                      >
                        Forgot your password?
                      </p>
                    </div>

                    <div
                      className="flexRow"
                      style={{ justifyContent: "flex-end" }}
                    >
                      <PrimaryButton
                        title="Login"
                        style={{ width: "24rem" }}
                        onClick={onSubmit}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className={styles.login__right}>
              <div className={styles.login__right__container}>
                <h3 className="sectionTitle">New Customer</h3>
                <p className="bodyText">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                  vel sem ante. Sed dignissim congue ex, sed posuere mi accumsan
                  eu. Integer tellus magna.
                </p>
                <BlackOutlineButton
                  title="Register"
                  style={{ width: "24rem" }}
                  onClick={() => router.push("/register")}
                />
              </div>
            </div>
          </>
        ) : (
          <div
            style={{
              margin: "2rem 0",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              width: "100%",
            }}
          >
            <h3 className="sectionTitle">You are already logged in</h3>
            <BlackOutlineButton
              title="Log Out"
              style={{ width: "24rem" }}
              onClick={onLogOut}
            />
          </div>
        )}
      </section>

      <Footer />
    </div>
  );
}
