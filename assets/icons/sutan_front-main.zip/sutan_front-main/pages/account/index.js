import Link from "next/link";
import Image from "next/image";

import Header from "../../components/header";
import Footer from "../../components/footer";
import SubHeader from "../../components/subHeader";
import Breadcrumbs from "../../components/breadcrumbs";
import Accordion from "../../components/accordion";
import { PrimaryButton, BlackOutlineButton } from "../../components/buttons";

import styles from "../../styles/Account.module.scss";

export default function Checkout() {
  return (
    <div className={styles.container}>
      <Header />

      <Breadcrumbs>
        <Link href="/">Home</Link>
        <Link href="/">Account</Link>
      </Breadcrumbs>

      <SubHeader>
        My <strong>Account</strong>
      </SubHeader>

      <section className={styles.account}>
        <div className={styles.account__left}>
          <div className={styles.account__left__container}>
            <Accordion
              title="My Account"
              isShow={true}
              style={{ display: "flex", flexDirection: "column" }}
            >
              <button className="accordionBtn">Dashboard</button>
              <button className="accordionBtn">Orders</button>
              <button className="accordionBtn">Downloads</button>
              <button className="accordionBtn active">Addresses</button>
              <button className="accordionBtn">Account details</button>
              <button className="accordionBtn">Wishlist</button>
              <button className="accordionBtn">Logout</button>
            </Accordion>
          </div>
        </div>

        <div className={styles.account__right}>
          <div className={styles.account__right__container}>
            <div className="form" style={{ width: "100%" }}>
              <h3 className="form__sectionTitle" style={{ marginTop: 0 }}>
                Login
              </h3>

              <div className="flexRow">
                <div className="form__control flexRow__col">
                  <label className="form__label">First name (optional)</label>
                  <input className="form__input" type="text" />
                </div>

                <div className="form__control flexRow__col">
                  <label className="form__label">Last name</label>
                  <input className="form__input" type="text" />
                </div>
              </div>

              <div className="form__control">
                <label className="form__label">Country/Region</label>
                <select className="form__input">
                  <option></option>
                </select>
              </div>

              <div className="form__control">
                <label className="form__label">Address</label>
                <input className="form__input" type="text" />
              </div>

              <div className="form__control">
                <label className="form__label">
                  Apartment, suite, etc. (optional)
                </label>
                <input className="form__input" type="text" />
              </div>

              <div className="flexRow">
                <div className="form__control flexRow__col">
                  <label className="form__label">City</label>
                  <input className="form__input" type="text" />
                </div>

                <div className="form__control flexRow__col">
                  <label className="form__label">Postal code</label>
                  <input className="form__input" type="text" />
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  marginTop: "2rem",
                }}
              >
                <PrimaryButton title="Update" style={{ width: "24rem" }} />
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
