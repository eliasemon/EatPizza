import Link from "next/link";
import Image from "next/image";

import Header from "../../components/header";
import Footer from "../../components/footer";
import SubHeader from "../../components/subHeader";
import Breadcrumbs from "../../components/breadcrumbs";
import ProductCard from "../../components/productCard";
import ProductQuantity from "../../components/productQuantity";
import { PrimaryButton } from "../../components/buttons";

import styles from "../../styles/Cart.module.scss";
import { useContext } from "react";
import AppContext from "../../context/AppContext";
import SingleCartItem from "../../components/cart/SingleCartItem";
import { useRouter } from "next/router";

export default function Shop() {
  const route = useRouter();
  const { cartData, cartItemtotal, setCartItemTotal } = useContext(AppContext);
  const getTotalPrice = () => {
    const totals = Object.values(cartItemtotal ?? {});
    return totals?.reduce((accum, price) => accum + price, 0);
  };
  return (
    <div className={styles.container}>
      <Header />

      <Breadcrumbs>
        <Link href="/">Home</Link>
        <Link href="/">Your Shopping Cart</Link>
      </Breadcrumbs>

      <SubHeader>
        Shopping <strong>Cart</strong>
      </SubHeader>

      <section className={styles.cart}>
        <header className={styles.cart__header}>
          <div className={styles.cart__container} style={{ height: "100%" }}>
            <div className={styles.cart__remove}></div>
            <div className={styles.cart__product}>Product</div>
            <div className={styles.cart__price}>Price</div>
            <div className={styles.cart__color}>Color</div>
            <div className={styles.cart__quantity}>Quantity</div>
            <div
              className={styles.cart__subtotal}
              style={{ justifyContent: "flex-end" }}
            >
              Subtotal
            </div>
          </div>
        </header>

        <div className={styles.cart__list} style={{ marginBottom: 40 }}>
          {cartData?.map((item) => (
            <SingleCartItem
              item={item}
              key={item?.productRef?.id}
              setCartItemTotal={setCartItemTotal}
            />
          ))}

          <div className={styles.cart__container} style={{ marginTop: 24 }}>
            <div className={styles.footerSpacer}></div>
            <div
              style={{
                display: "flex",
                flexGrow: 2,
                flexBasis: 10,
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <span className={styles.totalText}>Total</span>
              <span className={styles.priceText}>
                ${getTotalPrice().toFixed(2)}
              </span>
            </div>
          </div>

          <div className={styles.cart__container} style={{ marginTop: 24 }}>
            <div className={styles.footerSpacer}></div>
            <div style={{ flexGrow: 2, flexBasis: 10 }}>
              <PrimaryButton
                title="Proceed to Checkout"
                style={{ width: "100%" }}
                onClick={() => {
                  route.push("/checkout");
                }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* <div className="products">
        <h4 className="products__title">
          Recent View <strong>Products</strong>
        </h4>
        <div className="products__container">
          <ProductCard
            title="Linen-blend Shirt"
            price="$15.00"
            prevPrice="$17.00"
            rating="5"
            totalRating="11"
            img="./../product_pic01.png"
          />
          <ProductCard
            title="Boxy Denim Jacket"
            price="$20.00"
            prevPrice="$25.00"
            rating="3"
            totalRating="24"
            img="./../product_pic01.png"
          />
          <ProductCard
            title="Denim Jacket"
            price="$13.00"
            prevPrice="$16.00"
            img="./../product_pic01.png"
          />
          <ProductCard
            title="High Ankle Jeans"
            price="$18.00"
            prevPrice="$21.00"
            rating="4"
            totalRating="7"
            img="./../product_pic01.png"
          />
        </div>
      </div> */}

      <Footer />
    </div>
  );
}
