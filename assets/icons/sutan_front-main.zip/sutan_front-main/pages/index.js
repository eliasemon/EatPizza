import Header from "../components/header";
import Footer from "../components/footer";
import HomeHeaderCarousel from "../components/homeHeaderCarousel";
import SectionTitle from "../components/sectionTitle";
import ProductCard from "../components/productCard";

import styles from "../styles/Home.module.scss";
import { useRouter } from "next/router";
import {
  getPopularProducts,
  getRecentProducts,
  getSalesProducts,
} from "../utils/products";
import CollectionsComponent from "../components/pages-sections/homePage/Collections";
import NewArrivals from "../components/pages-sections/homePage/NewArrivals";
import SalesProducts from "../components/pages-sections/homePage/SalesProducts";
import Populars from "../components/pages-sections/homePage/Populars";
import RecentViews from "../components/pages-sections/homePage/RecentViews";
import { client } from "../utils/Apollo/apollo";
import {
  GET_LATEST_PRODUCTS,
  GET_POPULAR_PRODUCTS,
  GET_RECENT_VIEW_PRODUCTS,
  GET_SALES_PRODUCTS,
} from "../utils/queries/products";
import { useQuery } from "@apollo/client";

export default function Home({ latestData, salesData, popularData }) {
  console.log("latestData", latestData);
  return (
    <div className={styles.container}>
      <Header />
      <HomeHeaderCarousel />

      <CollectionsComponent />
      {latestData && <NewArrivals products={latestData} />}

      {salesData && <SalesProducts products={salesData} />}

      {popularData && <Populars products={popularData} />}
      <Footer />
    </div>
  );
}

// get static props of products in product collection in firebase
export async function getStaticProps() {
  // get 4 recent products with synthetized createdAt and updatedAt
  const latestData = await client.query({ query: GET_LATEST_PRODUCTS });
  const salesData = await client.query({ query: GET_SALES_PRODUCTS });
  const popularData = await client.query({ query: GET_POPULAR_PRODUCTS });

  // console.log("latestData", latestData?.data.products.nodes);
  // console.log("salesData", salesData?.products?.nodes);
  // console.log("popularData", popularData?.products?.nodes);
  // console.log("recentData", recentData.recent_view_products.nodes);

  return {
    props: {
      latestData: latestData?.data.products.nodes,
      salesData: salesData?.data.products.nodes,
      popularData: popularData?.data.products.nodes,
    },
  };
}
