import {
  DocumentReference,
  getDoc,
  orderBy,
  where,
  limit,
  getDocs,
  query,
} from "firebase/firestore";
import { colRef, currentTime, docRef } from "./services";

export const PRODUCT = {
  name: "",
  tags: [], // array of strings
  description: "",
  price: 0,
  images: [], // array of images links
  category: "Women",
  nameIndex: [],
  // subCategory: '',
  brand: "",
  quantity: 0,
  salesCount: 0,
  viewCount: 0,
  colors: [],
  sizes: [],
  variations: [],
  status: true,
  createdAt: currentTime(),
  updatedAt: currentTime(),
  viewCount: 0,
  salePrice: 0,
  rating: 0,
  published: false,
  ratingCount: 0,
  sku: "",
  tags: [],
  isSimple: true,
  shipping: {
    weight: 0,
    height: 0,
    width: 0,
    length: 0,
  },
};

export const PRODUCTVARIANT = {
  title: "",
  options: [],
  price: 0,
  quantity: 0,
  sold: 0,
  shipping: {
    weight: 0,
    height: 0,
    width: 0,
    length: 0,
  },
};

export const onProductCreate = async (productData) => {};

export const onProductDelete = async (prodId) => {};

export const onProductUpdate = async (update, prodId) => {};

export const getSalesProducts = async (myLimit = 10) => {
  // get products where salesPrice > 0 in firebase products collection
  // return products

  const products = await getDocs(
    query(
      colRef("products"),
      where("salePrice", ">", 0),
      orderBy("salePrice", "desc"),
      orderBy("createdAt", "desc"),
      limit(myLimit)
    )
  );

  return products.docs.map((doc) => {
    return {
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt.toDate().getTime(), // get timestamp
      updatedAt: doc.data().updatedAt.toDate().getTime(), // get timestamp
      path: doc.ref.path,
    };
  });
};

export const getProductsByCategory = async (category, myLimit = 10) => {
  // get products by category in firebase products collection
  // return products

  const products = await getDocs(
    query(
      colRef("products"),
      where("category", "==", category),
      orderBy("createdAt", "desc"),
      limit(myLimit)
    )
  );
  return products.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt.toDate().getTime(), // get timestamp
    updatedAt: doc.data().updatedAt.toDate().getTime(), // get timestamp
    path: doc.ref.path,
  }));
};

export const getPopularProducts = async (myLimit = 10) => {
  // get products by viewCount in firebase products collection
  // return products

  const products = await getDocs(
    query(colRef("products"), orderBy("viewCount", "desc"), limit(myLimit))
  );
  return products.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt.toDate().getTime(), // get timestamp
    updatedAt: doc.data().updatedAt.toDate().getTime(), // get timestamp
    path: doc.ref.path,
  }));
};

export const getRecentProducts = async (myLimit = 10) => {
  // get products by createdAt in firebase products collection
  // return products

  const products = await getDocs(
    query(colRef("products"), orderBy("createdAt", "desc"), limit(myLimit))
  );
  return products.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt.toDate().getTime(), // get timestamp
    updatedAt: doc.data().updatedAt.toDate().getTime(), // get timestamp
    path: doc.ref.path,
  }));
};

export const getProductsByTag = async (tag, myLimit = 10) => {
  // get products by tag in firebase products collection
  // return products

  const products = await getDocs(
    query(
      colRef("products"),
      where("tags", "array-contains", tag),
      orderBy("createdAt", "desc"),
      limit(myLimit)
    )
  );

  return products.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt.toDate().getTime(), // get timestamp
    updatedAt: doc.data().updatedAt.toDate().getTime(), // get timestamp
    path: doc.ref.path,
  }));
};

export const getProductsByBrand = async (brand, myLimit = 10) => {
  // get products by brand in firebase products collection
  // return products

  const products = await getDocs(
    query(
      colRef("products"),
      where("brand", "==", brand),
      orderBy("createdAt", "desc"),
      limit(myLimit)
    )
  );
  return products.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt.toDate().getTime(), // get timestamp
    updatedAt: doc.data().updatedAt.toDate().getTime(), // get timestamp
    path: doc.ref.path,
  }));
};

export const getProductsBySearch = async (search, myLimit = 10) => {
  // get products by search in firebase products collection
  // return products

  const products = await getDocs(
    query(
      colRef("products"),
      where("nameIndex", "array-contains", search),
      orderBy("createdAt", "desc"),
      limit(myLimit)
    )
  );
  return products.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt.toDate().getTime(), // get timestamp
    updatedAt: doc.data().updatedAt.toDate().getTime(), // get timestamp
    path: doc.ref.path,
  }));
};

export const getProductById = async (id) => {
  // get product by id in firebase products collection
  // return product

  const product = await getDoc(docRef("products", id));
  return { id: product.id, ...product.data(), path: product.ref.path };
};

// get all products in firebase products collection
// return products

export const getAllProducts = async () => {
  const products = await getDocs(colRef("products"));
  return products.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt.toDate().getTime(), // get timestamp
    updatedAt: doc.data().updatedAt.toDate().getTime(), // get timestamp
    path: doc.ref.path,
  }));
};

// generate product paths using getStaticPaths and nameIndex
// Path: pages/products/[id].js
// import { getProductById } from "../../utils/products";
// import { getProductsBySearch } from "../../utils/products";
// import { getProductsByTag } from "../../utils/products";
// import { getProductsByBrand } from "../../utils/products";
// import { getProductsByCategory } from "../../utils/products";
// import { getPopularProducts } from "../../utils/products";
// import { getRecentProducts } from "../../utils/products";

// export async function getStaticPaths() {
//   // get all products
//   // generate paths for all products
//   // return paths

//   const products = await getRecentProducts(100);
//   const paths = products.map((product) => ({
//     params: { id: product.id },
//   }));
//   return { paths, fallback: false };
// }
