import { deleteDoc, doc, getDoc, getDocs, setDoc } from "firebase/firestore";
import { colRef, currentTime, docReference } from "./services";

const CARTITEM = {
  productRef: null,
  quantity: 0,
  createdAt: null,
  updatedAt: null,
};

export const onAddToCart = async (productRef, quantity, uid) => {
  const cartItem = {
    productRef,
    quantity,
    createdAt: currentTime(),
    updatedAt: currentTime(),
  };

  // check if product already exists in cart
  // if so, update quantity
  // else, add to cart
  //
  const cartItemRef = docReference(`users/${uid}/cart/${productRef.id}`);
  const cartItemDoc = await getDoc(cartItemRef);
  if (cartItemDoc.exists()) {
    const cartItem = cartItemDoc.data();
    cartItem.quantity += quantity;
    cartItem.updatedAt = currentTime();
    await setDoc(cartItemRef, cartItem);
  } else {
    await setDoc(cartItemRef, cartItem);
  }
  return cartItem;
};

export const onRemoveFromCart = async (productRef, uid) => {
  await deleteDoc(doc(colRef(`users/${uid}/cart`), productRef.id));
};

export const onRemoveAllFromCart = async (uid) => {
  const cartItems = await getDocs(colRef(`users/${uid}/cart`));
  cartItems.forEach(async (doc) => {
    await deleteDoc(doc.ref);
  });
};

export const onGetCartItems = async (uid) => {
  const cartItems = await getDocs(colRef(`users/${uid}/cart`));
  return cartItems.docs.map((doc) => ({
    id: doc.id,
    ref: doc.ref,
    ...doc.data(),
  }));
};
