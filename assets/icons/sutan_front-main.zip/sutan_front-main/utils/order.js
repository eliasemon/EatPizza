import { currentTime } from "./services";

export const ORDERSTATUS = {
  PAID: "paid",
  UNPAID: "unpaid",
  CANCELLED: "cancelled",
  PENDING: "pending",
  REFUNDED: "refunded",
  SHIPPED: "shipped",
  DELIVERED: "delivered",
  RETURNED: "returned",
};

export const ORDERDETAILS = {
  createdOn: currentTime(),
  products: [
    {
      quantity: null,
      price: null,
      color: null,
      size: null,
      imageUrl: null,
      name: "",
      productRef: null,
    },
  ],
  total: 0,
  shipping: {
    fullName: "",
    address: "",
    city: "",
    country: "United States",
    zip: "",
    apt: "",
  },
  billing: {
    fullName: "",
    address: "",
    city: "",
    country: "United States",
    zip: "",
    apt: "",
  },
  orderNote: "",
  orderStatus: ORDERSTATUS.PAID,
  contactInfo: "",
  receiptSent: false,
};
