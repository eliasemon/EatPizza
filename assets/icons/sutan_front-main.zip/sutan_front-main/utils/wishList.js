import { deleteDoc, doc, getDoc, setDoc } from "firebase/firestore";
import { colRef, currentTime, docReference } from "./services";

const CARTITEM = {
  productRef: null,
  createdAt: null,
};

export const addToWish = async (productRef, uid) => {
  const cartItem = {
    productRef,
    createdAt: currentTime(),
  };

  // check if product already exists in cart
  // if so, update quantity
  // else, add to cart
  //
  const cartItemRef = docReference(`users/${uid}/wishList/${productRef.id}`);
  const cartItemDoc = await getDoc(cartItemRef);
  if (cartItemDoc.exists()) {
    deleteDoc(cartItemRef);
  } else {
    await setDoc(cartItemRef, cartItem);
  }
  return cartItem;
};

export const onRemoveFromCart = async (productRef, uid) => {
  await deleteDoc(doc(colRef(`users/${uid}/cart`), productRef.id));
};

export const onRemoveAllFromCart = async (uid) => {
  const cartItems = await getDocs(colRef(`users/${uid}/cart`));
  cartItems.forEach(async (doc) => {
    await deleteDoc(doc.ref);
  });
};

export const onGetCartItems = async (uid) => {
  const cartItems = await getDocs(colRef(`users/${uid}/cart`));
  return cartItems.docs.map((doc) => ({
    id: doc.id,
    ref: doc.ref,
    ...doc.data(),
  }));
};
