import { gql } from "@apollo/client";

export const GET_PRODUCTS = gql`
  query {
    products(where: { orderby: { field: DATE } }, first: 500) {
      nodes {
        id
        averageRating
        shortDescription
        slug
        reviewCount
        productId: databaseId

        image {
          id
          sourceUrl
          altText
        }
        galleryImages {
          nodes {
            altText
            sourceUrl
          }
        }
        ... on VariableProduct {
          id
          name
          price
          shortDescription
          salePrice
          stockStatus
          attributes {
            nodes {
              name
              options
            }
          }
          image {
            id
            sourceUrl

            altText
          }
          variations {
            nodes {
              image {
                altText
                sourceUrl
              }
              price
              name
              salePrice
              stockStatus
              attributes {
                nodes {
                  name
                  label
                  value
                }
              }
            }
          }
        }
        ... on SimpleProduct {
          id
          name
          salePrice
          stockStatus
          price
          image {
            id
            sourceUrl
          }
        }
        description
      }
    }
  }
`;

export const GET_PRODUCTS_SLUGS = gql`
  query {
    products(
      first: 500
      where: { orderby: { field: DATE }, stockStatus: IN_STOCK }
    ) {
      nodes {
        id
        slug
      }
    }
  }
`;

export const GET_LATEST_PRODUCTS = gql`
  query {
    products(
      where: { orderby: { field: DATE }, stockStatus: IN_STOCK }
      first: 4
    ) {
      nodes {
        id
        productId: databaseId
        averageRating
        shortDescription
        slug
        reviewCount
        image {
          id
          sourceUrl
          altText
        }
        galleryImages {
          nodes {
            altText
            sourceUrl
          }
        }
        ... on VariableProduct {
          id
          name
          price
          shortDescription
          salePrice
          stockStatus
          attributes {
            nodes {
              name
              options
            }
          }
          image {
            id
            sourceUrl

            altText
          }
          variations {
            nodes {
              image {
                altText
                sourceUrl
              }
              price
              name
              salePrice
              stockStatus
              attributes {
                nodes {
                  name
                  label
                  value
                }
              }
            }
          }
        }
        ... on SimpleProduct {
          id
          name
          salePrice
          stockStatus
          price
          image {
            id
            sourceUrl
          }
        }
        description
      }
    }
  }
`;

export const GET_SALES_PRODUCTS = gql`
  query {
    products(
      where: { orderby: { field: DATE }, stockStatus: IN_STOCK, onSale: true }
      first: 4
    ) {
      nodes {
        id
        averageRating
        shortDescription
        slug
        reviewCount
        productId: databaseId
        image {
          id
          sourceUrl
          altText
        }
        galleryImages {
          nodes {
            altText
            sourceUrl
          }
        }
        ... on VariableProduct {
          id
          name
          price
          shortDescription
          salePrice
          stockStatus
          attributes {
            nodes {
              name
              options
            }
          }
          image {
            id
            sourceUrl

            altText
          }
          variations {
            nodes {
              image {
                altText
                sourceUrl
              }
              price
              name
              salePrice
              stockStatus
              attributes {
                nodes {
                  name
                  label
                  value
                }
              }
            }
          }
        }
        ... on SimpleProduct {
          id
          name
          salePrice
          price
          stockStatus
          image {
            id
            sourceUrl
          }
        }
        description
      }
    }
  }
`;

export const GET_POPULAR_PRODUCTS = gql`
  query {
    products(
      where: {
        orderby: { field: TOTAL_SALES, order: DESC }
        stockStatus: IN_STOCK
      }
      first: 4
    ) {
      nodes {
        id
        averageRating
        shortDescription
        slug
        reviewCount
        productId: databaseId
        image {
          id
          sourceUrl
          altText
        }
        galleryImages {
          nodes {
            altText
            sourceUrl
          }
        }
        ... on VariableProduct {
          id
          name
          price
          shortDescription
          salePrice
          stockStatus
          attributes {
            nodes {
              name
              options
            }
          }
          image {
            id
            sourceUrl

            altText
          }
          variations {
            nodes {
              image {
                altText
                sourceUrl
              }
              price
              name
              salePrice
              stockStatus
              attributes {
                nodes {
                  name
                  label
                }
              }
            }
          }
        }
        ... on SimpleProduct {
          id
          name
          salePrice
          price
          stockStatus
          image {
            id
            sourceUrl
          }
        }
        description
      }
    }
  }
`;

export const GET_FEATURED_PRODUCTS = gql`
  query {
    products(
      where: { orderby: { field: DATE }, stockStatus: IN_STOCK, featured: true }
      first: 4
    ) {
      nodes {
        id
        averageRating
        shortDescription
        slug
        reviewCount
        productId: databaseId
        image {
          id
          sourceUrl
          altText
        }
        galleryImages {
          nodes {
            altText
            sourceUrl
          }
        }
        ... on VariableProduct {
          id
          name
          price
          shortDescription
          salePrice
          stockStatus
          attributes {
            nodes {
              name
              options
            }
          }
          image {
            id
            sourceUrl

            altText
          }
          variations {
            nodes {
              image {
                altText
                sourceUrl
              }
              price
              name
              salePrice
              stockStatus
              attributes {
                nodes {
                  name
                  label
                }
              }
            }
          }
        }
        ... on SimpleProduct {
          id
          name
          salePrice
          price
          stockStatus
          image {
            id
            sourceUrl
          }
        }
        description
      }
    }
  }
`;

export const GET_PRODUCT_BY_SLUG = gql`
  query GET_PRODUCT_BY_SLUG($slug: ID!) {
    product(id: $slug, idType: SLUG) {
      id
      averageRating
      shortDescription
      slug
      reviewCount
      productId: databaseId

      reviews {
        nodes {
          commentId
          commentedOn {
            node {
              date
              status
            }
          }
          content
          date
          author {
            node {
              avatar {
                url
              }
              email
              name
            }
          }
          replies {
            nodes {
              author {
                node {
                  avatar {
                    url
                  }
                  email
                  name
                }
              }
              content
            }
          }
        }
      }

      image {
        id
        sourceUrl
        altText
      }
      galleryImages {
        nodes {
          altText
          sourceUrl
        }
      }
      ... on VariableProduct {
        id
        name
        price
        shortDescription
        salePrice
        stockStatus
        description
        attributes {
          nodes {
            name
            options
          }
        }
        image {
          id
          sourceUrl

          altText
        }
        variations {
          nodes {
            image {
              altText
              sourceUrl
            }
            price
            name
            salePrice
            stockStatus
            attributes {
              nodes {
                name
                label
                value
              }
            }
          }
        }
      }
      ... on SimpleProduct {
        id
        name
        salePrice
        price
        stockStatus
        description
        attributes {
          nodes {
            name
            options
          }
        }
        image {
          id
          sourceUrl
        }
      }
      description
      related(first: 4) {
        nodes {
          id
          averageRating
          shortDescription
          slug
          reviewCount
          productId: databaseId
          image {
            id
            sourceUrl
            altText
          }
          galleryImages {
            nodes {
              altText
              sourceUrl
            }
          }
          ... on VariableProduct {
            id
            name
            price
            shortDescription
            salePrice
            image {
              id
              sourceUrl

              altText
            }
            variations {
              nodes {
                image {
                  altText
                  sourceUrl
                }
                price
                name
                salePrice
                attributes {
                  nodes {
                    name
                    label
                  }
                }
              }
            }
          }
          ... on SimpleProduct {
            id
            name
            salePrice
            price
            image {
              id
              sourceUrl
            }
          }
          description
        }
      }
    }
  }
`;

export const GET_SEARCHED_PRODUCTS = gql`
  query GET_SEARCHED_PRODUCTS($search: String!) {
    products(where: { search: $search }) {
      nodes {
        id
        averageRating
        shortDescription
        slug
        reviewCount
        productId: databaseId
        image {
          id
          sourceUrl
          altText
        }
        galleryImages {
          nodes {
            altText
            sourceUrl
          }
        }
        ... on VariableProduct {
          id
          name
          price
          shortDescription
          salePrice
          stockStatus
          attributes {
            nodes {
              name
              options
            }
          }
          image {
            id
            sourceUrl

            altText
          }
          variations {
            nodes {
              image {
                altText
                sourceUrl
              }
              price
              name
              salePrice
              stockStatus
              attributes {
                nodes {
                  name
                  label
                }
              }
            }
          }
        }
        ... on SimpleProduct {
          id
          name
          salePrice
          price
          stockStatus
          image {
            id
            sourceUrl
          }
        }
        description
      }
    }
  }
`;

export const GET_PRODUCTS_BY_CATEGORY = gql`
  query GET_PRODUCTS_BY_CATEGORY($category: String!) {
    products(where: { category: $category }) {
      nodes {
        id
        averageRating
        shortDescription
        slug
        reviewCount
        productId: databaseId
        image {
          id
          sourceUrl
          altText
        }
        galleryImages {
          nodes {
            altText
            sourceUrl
          }
        }
        ... on VariableProduct {
          id
          name
          price
          shortDescription
          salePrice
          stockStatus
          attributes {
            nodes {
              name
              options
            }
          }

          image {
            id
            sourceUrl

            altText
          }
          variations {
            nodes {
              image {
                altText
                sourceUrl
              }
              price
              name
              salePrice
              stockStatus
              attributes {
                nodes {
                  name
                  label
                }
              }
            }
          }
        }
        ... on SimpleProduct {
          id
          name
          salePrice
          price
          stockStatus
          image {
            id
            sourceUrl
          }
        }
        description
      }
    }
  }
`;

export const GET_RELATED_PRODUCTS = gql`
  query GET_RELATED_PRODUCTS($id: ID!) {
    product(id: $id) {
      id
      related(first: 4) {
        nodes {
          id
          averageRating
          shortDescription
          slug
          reviewCount
          productId: databaseId
          stockStatus
          image {
            id
            sourceUrl
            altText
          }
          galleryImages {
            nodes {
              altText
              sourceUrl
            }
          }
          ... on VariableProduct {
            id
            name
            price
            shortDescription
            salePrice
            stockStatus
            attributes {
              nodes {
                name
                options
              }
            }
            image {
              id
              sourceUrl

              altText
            }
            variations {
              nodes {
                image {
                  altText
                  sourceUrl
                }
                price
                name
                salePrice
                stockStatus
                description
                attributes {
                  nodes {
                    name
                    label
                  }
                }
              }
            }
          }
          ... on SimpleProduct {
            id
            name
            salePrice
            price
            stockStatus
            description
            image {
              id
              sourceUrl
            }
          }
          description
        }
      }
    }
  }
`;

// export const GET_RECENT_VIEW_PRODUCTS = gql`
//   query {
//     recent_view_products(first: 4) {
//       nodes {
//         id
//         name
//         short_description
//         regular_price
//         sale_price
//         images {
//           nodes {
//             src
//             alt
//           }
//         }
//         reviews {
//           nodes {
//             id
//             rating
//             review
//           }
//         }
//         variations {
//           nodes {
//             id
//             name
//             regular_price
//             sale_price
//             stock_status
//           }
//         }
//       }
//     }
//   }
// `;
