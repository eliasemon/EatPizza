import { DocumentReference, setDoc } from "firebase/firestore";
import { currentTime, docReference, onSignUp } from "./services";

export const USERDATA = {
  firstName: "",
  lastName: "",
  email: "",
  isBlocked: false,
  phoneNumber: "",
  profilePic: "",
  role: DocumentReference,
  uid: "",
  createdAt: currentTime(),
  updatedAt: currentTime(),
  shippingAddress: null,
  billingAddress: null,
};

export const USERADDRESS = {
  address: "",
  city: "",
  country: "",
  state: "",
  zipCode: "",
};

export const CARTDATA = {
  productRef: DocumentReference,
  quantity: 1,
  createdAt: currentTime(),
  updatedAt: currentTime(),
};

export const onUserCreate = async (userData) => {
  const userAuth = await onSignUp(userData.email, userData.password);
  // const uid = userAuth.user.uid;
  const userRef = docReference(`users/${userAuth.user.uid}`);

  const { uid, ...user } = USERDATA;
  user.firstName = userData.firstName;
  user.lastName = userData.lastName;
  user.email = userData.email;
  user.role = docReference(`roles/user`);
  await setDoc(userRef, user);
};
