// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import {
  getFirestore,
  doc,
  setDoc,
  Timestamp,
  collection,
  addDoc,
  getDoc,
  collectionGroup,
} from "firebase/firestore";
import {
  getDownloadURL,
  getStorage,
  ref,
  uploadBytes,
  uploadBytesResumable,
} from "firebase/storage";
import {
  createUserWithEmailAndPassword,
  getAuth,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB0FO5h_0LeA1V7qfBedBy8uAb8NyQ9MvI",
  authDomain: "sutan-s.firebaseapp.com",
  projectId: "sutan-s",
  storageBucket: "sutan-s.appspot.com",
  messagingSenderId: "137713257533",
  appId: "1:137713257533:web:7c29450fd7223d3b7cee54",
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);

export const currentTime = () => {
  return Timestamp.now();
};

export const colRef = (_colPath, isGroup = false) => {
  return isGroup ? collectionGroup(db, _colPath) : collection(db, _colPath);
};

export const docReference = (_docPath) => {
  console.log("docReference", _docPath);
  return doc(db, _docPath);
};

export const emptyRef = (_col) => {
  return doc(collection(db, _col));
};

export const onSignUp = async (email, password) => {
  return await createUserWithEmailAndPassword(auth, email, password);
};

export const onResetPass = async (email) => {
  return await sendPasswordResetEmail(auth, email);
};

export const onLogin = async (email, password) => {
  return await signInWithEmailAndPassword(auth, email, password);
};

export const onLogOut = async () => {
  return await signOut(auth);
};

export const createDocFromId = async (collection, docId, data) => {
  let docRef = doc(db, collection, docId);
  return await setDoc(docRef, data);
};

export const docRef = (collection, docId) => {
  return doc(db, collection, docId);
};
export const addDocument = async (colName, data) => {
  const colRef = collection(db, colName);
  return await addDoc(colRef, data);
};

export const getDocById = async (colName, docId) => {
  const docRef = doc(db, colName, docId);
  return await getDoc(docRef);
};

export const addOrUpdate = async (_path, _data) => {
  return await setDoc(docReference(_path), _data, { merge: true });
};

export const uploadFile = async (file, path) => {
  const storageRef = ref(storage, path);
  const uploadTask = await uploadBytes(storageRef, file);
  return await getDownloadURL(uploadTask.ref);
};
