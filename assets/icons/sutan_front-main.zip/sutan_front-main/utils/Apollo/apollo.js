import { ApolloClient, ApolloLink } from "@apollo/client";
import { createHttpLink } from "@apollo/client";
import { setContext } from "@apollo/client/link/context";
import { InMemoryCache } from "@apollo/client";
import { useMutation } from "@apollo/client";
import { useApolloClient } from "@apollo/client";
import { gql } from "@apollo/client";
import axios from "axios";

const httpLink = createHttpLink({
  uri: `${process.env.NEXT_PUBLIC_WORDPRESS_URL}/graphql`,
  // fetch: axios,
});

const authLink = setContext((_, { headers }) => {
  // get the authentication token from session storage if it exists
  // let token = sessionStorage.getItem("token");
  // if (!token) {
  //   token = localStorage.getItem("anonymous_token");
  // }

  let token;
  if (typeof window !== "undefined") {
    token = sessionStorage.getItem("token");
    if (!token) {
      token = localStorage.getItem("anonymous_token");
    }
  }
  // return the headers to the context so httpLink can read them
  return {
    headers: {
      ...headers,
      authorization: token ? `Bearer ${token}` : "",
    },
  };
});

const client = new ApolloClient({
  link: ApolloLink.from([authLink, httpLink]),
  cache: new InMemoryCache(),
});

const LOGIN_MUTATION = gql`
  mutation login($input: LoginInput!) {
    login(input: $input) {
      jwtToken
      user {
        id
        email
        name
      }
    }
  }
`;
const SIGNUP_MUTATION = gql`
  mutation signup($input: SignupInput!) {
    signup(input: $input) {
      jwtToken
      user {
        id
        firstName
        lastName
        username
        email
      }
    }
  }
`;
function useAuth() {
  const [login, loginData] = useMutation(LOGIN_MUTATION);
  const [signup, signupData] = useMutation(SIGNUP_MUTATION);
  const client = useApolloClient();

  async function handleLogin(input) {
    const { data } = await login({ variables: { input } });
    sessionStorage.setItem("token", data.login.jwtToken);
    client.resetStore();
  }

  async function handleSignup(input) {
    const { data } = await signup({ variables: { input } });
    sessionStorage.setItem("token", data.signup.jwtToken);
    client.resetStore();
  }

  async function handleLogout() {
    sessionStorage.removeItem("token");
    client.resetStore();
  }

  return { handleLogin, handleSignup, handleLogout };
}

export { client, useAuth };
