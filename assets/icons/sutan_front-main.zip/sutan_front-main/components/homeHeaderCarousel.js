import styles from './styles/homeHeaderCarousel.module.scss';

export default function HomeHeaderCarousel({ children }) {
    return (
        <div className={styles.carousel}>
            <div className={styles.carousel__slide}>
                <div className={styles.carousel__slide__content}>
                    <div className={styles.flexColumn}>
                        <h2 className={styles.slideTitle01}>Exclusive</h2>
                        <h3 className={styles.slideTitle02}>Offer</h3>
                    </div>
                    <p className={styles.slideDetails}>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis nibh odio, dapibus ullamcorper felis ut, auctor scelerisque eros. </p>
                    <button className={styles.slideBtn}>Shop Now</button>
                
                    <img className={styles.slider01} src="./../slider_img_01.png" />
                </div>
            </div>
        </div>
    )
}