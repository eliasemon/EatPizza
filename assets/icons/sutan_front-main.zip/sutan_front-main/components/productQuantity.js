import { useState } from "react";
import Image from "next/image";

import styles from "./styles/productQuantity.module.scss";

export default function ProductQuantity(props) {
  return (
    <div className={styles.productQuantity} style={{ marginRight: 16 }}>
      <button
        className={styles.productQuantity__btn}
        onClick={props.onDecrease}
      >
        <Image src="/icons/minus-ico.svg" width={14} height={14} />
      </button>
      <label className={styles.productQuantity__value}>{props.quantity}</label>
      <button
        className={styles.productQuantity__btn}
        onClick={props.onIncrease}
      >
        <Image src="/icons/plus-ico.svg" width={14} height={14} />
      </button>
    </div>
  );
}
