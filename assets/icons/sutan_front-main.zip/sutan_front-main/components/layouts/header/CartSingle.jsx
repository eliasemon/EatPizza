import React, { useEffect, useMemo } from "react";
import { FlexBox } from "../../flex-box";
import BazaarButton from "../../BazaarButton";
import { Add, Close, Remove } from "@mui/icons-material";
import { Box } from "@mui/system";
import Link from "next/link";
import { useTheme } from "@mui/material/styles";
import BazaarAvatar from "../../BazaarAvatar";
import { H5, Tiny } from "../../Typography";
import BazaarIconButton from "../../BazaarIconButton";
import { deleteDoc, onSnapshot, updateDoc } from "firebase/firestore";

const CartSingle = ({ item, setCartItemTotal }) => {
  const { palette } = useTheme();
  const [product, setProduct] = React.useState(null);
  const [qty, setQty] = React.useState(item.quantity);

  const onRemove = () => {
    console.log("remove");
    deleteDoc(item.cartRef);
  };

  const onIncrease = () => {
    console.log("increase");
    setQty((prev) => prev + 1);

    updateDoc(item.cartRef, {
      quantity: qty + 1,
    });
  };

  const onDecrease = () => {
    console.log("decrease");
    if (qty === 1) return;
    setQty((prev) => prev - 1);
    updateDoc(item.cartRef, {
      quantity: qty - 1,
    });
  };

  useEffect(() => {
    return onSnapshot(item.productRef, (snap) => {
      if (!snap.exists()) return;

      setProduct({
        id: snap.id,
        ...snap.data(),
        ref: snap.ref,
      });
    });
  }, [item.productRef.id]);

  const renderPrice = useMemo(() => {
    if (!product) return 0;
    if (product?.salePrice && product?.salePrice < product?.price) {
      return product?.salePrice;
    }
    return product?.price;
  }, [product?.salePrice, product?.price, item.productRef.id]);

  useEffect(() => {
    setCartItemTotal((prev) => ({
      ...prev,
      [item.productRef.id]: renderPrice * qty,
    }));
  }, [qty, renderPrice]);

  return (
    <FlexBox
      py={2}
      px={2.5}
      alignItems="center"
      borderBottom={`1px solid ${palette.divider}`}
    >
      <FlexBox alignItems="center" flexDirection="column">
        <BazaarButton
          color="primary"
          variant="outlined"
          onClick={onIncrease}
          sx={{
            height: "32px",
            width: "32px",
            borderRadius: "300px",
          }}
        >
          <Add fontSize="small" />
        </BazaarButton>

        <Box fontWeight={600} fontSize="15px" my="3px">
          {qty}
        </Box>

        <BazaarButton
          color="primary"
          variant="outlined"
          disabled={qty === 1}
          onClick={onDecrease}
          sx={{
            height: "32px",
            width: "32px",
            borderRadius: "300px",
          }}
        >
          <Remove fontSize="small" />
        </BazaarButton>
      </FlexBox>

      <Link href={`/shop/${product?.id}`}>
        <BazaarAvatar
          mx={2}
          width={76}
          height={76}
          alt={product?.name}
          src={product?.images[0] || "/assets/images/products/iphone-x.png"}
        />
      </Link>

      <Box flex="1 1 0">
        <Link href={`/shop/${product?.id}`}>
          <H5 className="title" fontSize="14px">
            {product?.name}
          </H5>
        </Link>

        <Tiny color="grey.600">
          ${renderPrice.toFixed(2)} x {qty}
        </Tiny>

        <Box fontWeight={600} fontSize="14px" color="primary.main" mt={0.5}>
          ${(qty * renderPrice).toFixed(2)}
        </Box>
      </Box>

      <BazaarIconButton ml={2.5} size="small" onClick={onRemove}>
        <Close fontSize="small" />
      </BazaarIconButton>
    </FlexBox>
  );
};

export default CartSingle;
