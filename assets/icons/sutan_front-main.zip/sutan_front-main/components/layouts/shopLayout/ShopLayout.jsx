import React, { useCallback } from "react";
import { Apps, FilterList, ViewList } from "@mui/icons-material";
import {
  Box,
  Card,
  Container,
  Grid,
  IconButton,
  MenuItem,
  TextField,
  useMediaQuery,
} from "@mui/material";
import ShopLayout1 from "../ShopLayout1";
import Sidenav from "../../sidenav/Sidenav";
import Card1 from "../../Card1";
import Breadcrumbs from "../../breadcrumbs";
import Link from "next/link";
import SubHeader from "../../subHeader";
import { H5, Paragraph } from "../../Typography";
import { FlexBox } from "../../flex-box";
import ProductFilterCard from "../../ProductFilterCard";

const ShopLayout = ({ children }) => {
  const downMd = useMediaQuery((theme) => theme.breakpoints.down("md"));
  // const toggleView = useCallback((v) => () => setView(v), []);
  return (
    <ShopLayout1>
      <Breadcrumbs>
        <Link href="/">Home</Link>
        <Link href="/">Abby</Link>
      </Breadcrumbs>

      <SubHeader>
        Sales <strong>Products</strong>
      </SubHeader>
      <Container
        sx={{
          mt: 4,
          mb: 6,
          maxWidth: "1660px !important",
        }}
      >
        <Card1
          elevation={1}
          sx={{
            mb: "55px",
            display: "flex",
            flexWrap: "wrap",
            alignItems: "center",
            justifyContent: "space-between",
            p: {
              sm: "1rem 1.25rem",
              md: "0.5rem 1.25rem",
              xs: "1.25rem 1.25rem 0.25rem",
            },
          }}
        >
          <Box>
            <H5>Searching for “ mobile phone ”</H5>
            <Paragraph color="grey.600">48 results found</Paragraph>
          </Box>

          <FlexBox
            alignItems="center"
            columnGap={4}
            flexWrap="wrap"
            my="0.5rem"
          >
            <FlexBox alignItems="center" gap={1} flex="1 1 0">
              <Paragraph color="grey.600" whiteSpace="pre">
                Short by:
              </Paragraph>

              <TextField
                select
                fullWidth
                size="small"
                variant="outlined"
                placeholder="Short by"
                defaultValue={sortOptions[0].value}
                sx={{
                  flex: "1 1 0",
                  minWidth: "150px",
                }}
              >
                {sortOptions.map((item) => (
                  <MenuItem value={item.value} key={item.value}>
                    {item.label}
                  </MenuItem>
                ))}
              </TextField>
            </FlexBox>

            <FlexBox alignItems="center" my="0.25rem">
              {/* <Paragraph color="grey.600" mr={1}>
                View:
              </Paragraph>

              <IconButton onClick={toggleView("grid")}>
                <Apps
                  color={view === "grid" ? "primary" : "inherit"}
                  fontSize="small"
                />
              </IconButton>

              <IconButton onClick={toggleView("list")}>
                <ViewList
                  color={view === "list" ? "primary" : "inherit"}
                  fontSize="small"
                />
              </IconButton> */}

              {downMd && (
                <Sidenav
                  handle={
                    <IconButton>
                      <FilterList fontSize="small" />
                    </IconButton>
                  }
                >
                  <ProductFilterCard />
                </Sidenav>
              )}
            </FlexBox>
          </FlexBox>
        </Card1>

        <Grid container spacing={3}>
          <Grid
            item
            md={3}
            sx={{
              display: {
                md: "block",
                xs: "none",
              },
            }}
          >
            <ProductFilterCard />
          </Grid>

          <Grid item md={9} xs={12}>
            {children}
          </Grid>
        </Grid>
      </Container>
    </ShopLayout1>
  );
};

const sortOptions = [
  {
    label: "Relevance",
    value: "Relevance",
  },
  {
    label: "Date",
    value: "Date",
  },
  {
    label: "Price Low to High",
    value: "Price Low to High",
  },
  {
    label: "Price High to Low",
    value: "Price High to Low",
  },
];

export default ShopLayout;
