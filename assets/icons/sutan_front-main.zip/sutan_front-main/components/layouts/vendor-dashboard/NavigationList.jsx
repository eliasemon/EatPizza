import duotone from "../../icons/duotone";
export const navigations = [
  {
    type: "label",
    label: "Admin",
  },
  {
    name: "Dashboard",
    icon: duotone.Dashboard,
    path: "/dasherAimer/dashdash",
  },
  {
    name: "Products",
    icon: duotone.Products,
    path: "/dasherAimer/products",
    // children: [
    //   {
    //     name: "Product List",
    //   },
    //   {
    //     name: "Create Product",
    //     path: "/dasherAimer/products/create",
    //   },
    //   {
    //     name: "Category",
    //     path: "/dasherAimer/categories",
    //   },
    //   {
    //     name: "Brand",
    //     path: "/dasherAimer/brands",
    //   },
    //   {
    //     name: "Review",
    //     path: "/dasherAimer/product-reviews",
    //   },
    // ],
  },
  {
    name: "Orders",
    icon: duotone.Order,
    path: "/dasherAimer/orders",
  },
  {
    name: "Customers",
    icon: duotone.Customers,
    path: "/dasherAimer/customers",
  },

  // {
  //   name: "Support Tickets",
  //   icon: duotone.ElementHub,
  //   path: "/vendor/support-tickets",
  // },
  // {
  //   name: "Account Setting",
  //   icon: duotone.AccountSetting,
  //   path: "/vendor/account-setting",
  // },
  // {
  //   name: "Site Setting",
  //   icon: duotone.SiteSetting,
  //   path: "/vendor/site-settings",
  // },
  {
    name: "Logout",
    icon: duotone.Session,
    path: "/vendor/dashboard-version-2",
  },
];
