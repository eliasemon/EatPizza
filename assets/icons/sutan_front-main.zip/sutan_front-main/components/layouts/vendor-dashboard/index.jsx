import { Box, styled } from "@mui/material";
import { Fragment, useContext, useState } from "react";
import AppContext from "../../../context/AppContext";
import ShopLayout1 from "../ShopLayout1";
import DashboardNavbar from "./DashboardNavbar";
import DashboardSidebar from "./DashboardSidebar"; // styled components

const BodyWrapper = styled(Box)(({ theme, compact }) => ({
  transition: "margin-left 0.3s",
  marginLeft: compact ? "86px" : "280px",
  [theme.breakpoints.down("lg")]: {
    marginLeft: 0,
  },
}));
const InnerWrapper = styled(Box)(({ theme }) => ({
  transition: "all 0.3s",
  [theme.breakpoints.up("lg")]: {
    maxWidth: 1200,
    margin: "auto",
  },
  [theme.breakpoints.down(1550)]: {
    paddingLeft: "2rem",
    paddingRight: "2rem",
  },
}));

const VendorDashboardLayout = ({ children }) => {
  const { userData } = useContext(AppContext);
  const [sidebarCompact, setSidebarCompact] = useState(0);
  const [showMobileSideBar, setShowMobileSideBar] = useState(0); // handle sidebar toggle for desktop device

  const handleCompactToggle = () =>
    setSidebarCompact((state) => (state ? 0 : 1)); // handle sidebar toggle in mobile device

  const handleMobileDrawerToggle = () =>
    setShowMobileSideBar((state) => (state ? 0 : 1));

  return (
    <Fragment>
      {userData?.role?.id === "admin" ? (
        <Fragment>
          <DashboardSidebar
            sidebarCompact={sidebarCompact}
            showMobileSideBar={showMobileSideBar}
            setSidebarCompact={handleCompactToggle}
            setShowMobileSideBar={handleMobileDrawerToggle}
          />

          <BodyWrapper compact={sidebarCompact ? 1 : 0}>
            <DashboardNavbar handleDrawerToggle={handleMobileDrawerToggle} />
            <InnerWrapper>{children}</InnerWrapper>
          </BodyWrapper>
        </Fragment>
      ) : (
        <ShopLayout1>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "100vh",
              width: "100vw",
            }}
          >
            <p
              style={{
                fontSize: "2rem",
                fontWeight: "bold",
              }}
            >
              You are Not authorized to view this Page
            </p>
          </div>
        </ShopLayout1>
      )}
    </Fragment>
  );
};

export default VendorDashboardLayout;
