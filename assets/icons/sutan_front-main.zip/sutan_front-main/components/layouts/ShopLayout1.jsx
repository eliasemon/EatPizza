import React, { Fragment, useCallback, useState } from "react";
import Header from "../header";
import Breadcrumbs from "../breadcrumbs";
import SubHeader from "../subHeader";
import Footer from "../footer";
/**
 *  Used in:
 *  1. market-1, matket-2, gadget-shop,
 *     fashion-shop, fashion-shop-2, fashion-shop-3, furniture-shop, grocery3, gift-shop
 *  2. product details page
 *  3. order-confirmation page
 *  4. product-search page
 *  5. shops and shops-details page
 *  6. checkoutNavLayout and CustomerDashboadLayout component
 */
// ===================================================

// ===================================================
const ShopLayout1 = ({ children }) => {
  return (
    <Fragment>
      <Header />

      <div className="section-after-sticky">{children}</div>

      <Footer />
    </Fragment>
  );
};

export default ShopLayout1;
