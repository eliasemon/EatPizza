import { useState } from "react";
import Image from 'next/image';
import styles from './styles/accordion.module.scss';
import accordionIco from '../public/icons/accordion-ico.svg';

export default function Accordion({ title, children, isShow }) {
  const [isShowing, setIsShowing] = useState(isShow);

  const toggle = () => {
    setIsShowing(!isShowing);
  };

  return (
    <div className={styles.accordion}>
      <button
        className={styles.accordion__header}
        onClick={toggle}
        type="button"
      >
        <p>{title}</p>
        <Image
          src={accordionIco}
          alt="Accordion Ico"
          width="14"
          height="9"
          style={{ transform: isShowing ? "rotate(180deg)" : "rotate(0deg)", transition: ".5s" }}
        />
      </button>
      <div style={{ display: isShowing ? "flex" : "none", padding: "1.6rem 0", flexDirection: 'column', alignItems: 'flex-start' }}>{children}</div>
    </div>
  );
}
