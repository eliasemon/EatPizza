import React, { useEffect, useMemo } from "react";
import ProductCard from "../productCard";
import { deleteDoc, onSnapshot, updateDoc } from "firebase/firestore";
import styles from "../../styles/Cart.module.scss";
import ProductQuantity from "../productQuantity";
import Image from "next/image";

const SingleCartItem = ({ item, setCartItemTotal }) => {
  const [product, setProduct] = React.useState(null);
  const [qty, setQty] = React.useState(item.quantity);

  const renderPrice = useMemo(() => {
    if (!product) return 0;
    if (product?.salePrice && product?.salePrice < product?.price) {
      return product?.salePrice;
    }
    return product?.price;
  }, [product?.salePrice, product?.price, item.productRef.id]);

  const onRemove = () => {
    deleteDoc(item.cartRef);
  };

  const onIncrease = () => {
    setQty((prev) => prev + 1);

    updateDoc(item.cartRef, {
      quantity: qty + 1,
    });
  };

  const onDecrease = () => {
    if (qty === 1) return;
    setQty((prev) => prev - 1);
    updateDoc(item.cartRef, {
      quantity: qty - 1,
    });
  };

  useEffect(() => {
    return onSnapshot(item.productRef, (snap) => {
      if (!snap.exists()) return;

      setProduct({
        id: snap.id,
        ...snap.data(),
        ref: snap.ref,
        path: snap.ref.path,
      });
    });
  }, [item.productRef.id]);

  useEffect(() => {
    setCartItemTotal((prev) => ({
      ...prev,
      [item.productRef.id]: renderPrice * qty,
    }));
  }, [qty, renderPrice]);

  //   console.log("product", product);

  return (
    <div className={styles.cart__list__item}>
      <div className={styles.cart__container}>
        <div className={styles.cart__remove}>
          <button className="iconButton" onClick={onRemove}>
            <Image
              src="/icons/delete-ico.svg"
              objectFit="cover"
              width={24}
              height={24}
            />
          </button>
        </div>
        <div className={styles.cart__product}>
          <Image
            src={product?.images[0]}
            objectFit="cover"
            width={100}
            height={100}
            style={{ borderRadius: 4 }}
          />
          <span className={styles.title} style={{ marginLeft: 24 }}>
            {product?.name}
          </span>
        </div>
        <div className={styles.cart__price}>${renderPrice?.toFixed(2)}</div>
        <div className={styles.cart__color}>-</div>
        <div className={styles.cart__quantity}>
          <ProductQuantity
            quantity={qty}
            onIncrease={onIncrease}
            onDecrease={onDecrease}
          />
        </div>
        <div className={styles.cart__subtotal}>
          ${(qty * renderPrice).toFixed(2)}
        </div>
      </div>
    </div>
  );
};

export default SingleCartItem;
