import { useContext, useEffect, useMemo, useState } from "react";
import styles from "./styles/productCard.module.scss";
import Rating from "./rating";

import { SecondaryButton } from "./buttons";
import { HeartIcon, EyeIcon } from "./icons";

import ProductModal from "./productModal";
import { onAddToCart } from "../utils/cart";
import AppContext from "../context/AppContext";
import { docReference } from "../utils/services";
import { Drawer } from "@mui/material";
import MiniCart from "./mini-cart/MiniCart";
import { addToWish } from "../utils/wishList";
import Link from "next/link";

export default function ProductCard({ product }) {
  const [showModal, setShowModal] = useState(false);
  const [sidenavOpen, setSidenavOpen] = useState(false);
  // const [cart, setCart] = useContext(AppContext);
  const [showViewCart, setShowViewCart] = useState(false);
  const [requestError, setRequestError] = useState(null);
  const { userData, cartData, wishList } = useContext(AppContext);

  const [hasVariants, setHasVariants] = useState(false);

  const toggleSidenav = () => setSidenavOpen(!sidenavOpen);

  const existInCart = useMemo(() => {
    if (!cartData) return false;
    return cartData?.find((item) => item?.productRef?.id === product?.id);
  }, [cartData, product?.id]);

  const existInWishList = useMemo(() => {
    if (!wishList) return false;
    return wishList?.find((item) => item?.productRef?.id === product?.id);
  }, [wishList, product?.id]);

  const onSendToCart = () => {
    if (existInCart) {
      // alert("Product already in cart");
      toggleSidenav();
      return;
    }
    if (!userData?.ref?.id) {
      alert("Please login to add to cart");
      return;
    }
    if (!product?.id) {
      alert("Product not found");
      return;
    }

    const producRef = docReference(product?.path);

    onAddToCart(producRef, 1, userData?.ref?.id);
  };
  const onSendTOWishList = () => {
    if (!userData?.ref?.id) {
      alert("Please login to add to wishlist");
      return;
    }
    if (!product?.id) {
      alert("Product not found");
      return;
    }
    const producRef = docReference(product?.path);
    addToWish(producRef, userData?.ref?.id);
  };

  useEffect(() => {
    const uniqueAttributes = new Set();
    product?.variations?.nodes.forEach((variation) => {
      variation.attributes.nodes.forEach((attribute) => {
        uniqueAttributes.add(attribute.label);
      });
    });

    if (uniqueAttributes.size > 0) {
      setHasVariants(true);
    }
  }, [product]);

  return (
    <div className={styles.card}>
      <Drawer open={sidenavOpen} anchor="right" onClose={toggleSidenav}>
        <MiniCart />
      </Drawer>
      <div className={styles.card__pic}>
        <div className={styles.card__quickView}>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-end",
            }}
          >
            <button
              className={
                existInWishList ? styles.iconBtnActive : styles.iconBtn
              }
              onClick={onSendTOWishList}
            >
              <HeartIcon fill="var(--color-product-card-icon)" />
            </button>

            <ProductModal
              onClose={() => setShowModal(false)}
              show={showModal}
              product={product}
            />
            <button
              className={styles.iconBtn}
              onClick={() => setShowModal(true)}
            >
              <EyeIcon fill="var(--color-product-card-icon)" />
            </button>
          </div>
          <SecondaryButton
            title={existInCart ? "View Cart" : "Add to cart"}
            onClick={onSendToCart}
            disabled={hasVariants || product?.stockStatus !== "IN_STOCK"}
          />
        </div>

        <img
          src={product?.image?.sourceUrl ?? "./../product_pic01.png"}
          alt={product?.name}
        />
      </div>
      <Link href={`/shop${product?.slug ? `/${product?.slug}` : "/"}`}>
        <h4 className={styles.card__title}>{product?.name ?? ""}</h4>
        <div className={styles.flexRow}>
          <h5 className={styles.card__price}>
            {product?.salePrice ? product?.salePrice : product?.price}
            {product?.salePrice && (
              <span className={styles.card__prevPrice}>{product?.price}</span>
            )}
          </h5>
          {/* <div className={styles.card__rating}>
            <Rating rating={product?.averageRating ?? 0} />
            <p className={styles.card__rating__count}>
              {product?.reviewCount ?? 0}
            </p>
          </div> */}
        </div>
      </Link>
    </div>
  );
}
