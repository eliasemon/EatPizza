import Image from 'next/image';
import styles from './styles/rating.module.scss';
import starFillIco from '../public/icons/star-fill-ico.svg';
import starEmptyIco from '../public/icons/star-empty-ico.svg';

export default function Rating(props) {
    switch (props.rating) {
        case "5":
        return(
            <div className={styles.rating}>
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
            </div>
        )
        break;

        case "4":
        return(
            <div className={styles.rating}>
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
            </div>
        )
        break;

        case "3":
        return(
            <div className={styles.rating}>
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
            </div>
        )
        break;

        case "2":
        return(
            <div className={styles.rating}>
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
            </div>
        )
        break;

        case "1":
        return(
            <div className={styles.rating}>
                <Image src={starFillIco} alt="Star fill" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
            </div>
        )
        break;
    
        default:
        return(
            <div className={styles.rating}>
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
                <Image src={starEmptyIco} alt="Star empty" width="18" height="18" />
            </div>
        )
        break;
    }
}