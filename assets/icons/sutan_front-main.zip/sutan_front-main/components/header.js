import Link from "next/link";
import { useContext, useState } from "react";
import Image from "next/image";
import styles from "./styles/header.module.scss";
import { Badge, Box, Dialog, Drawer, styled } from "@mui/material";
import IconButton from "@mui/material/IconButton";

import logoText from "../public/logo_text.svg";
import logoSymbol from "../public/logo_symbol.png";

import { SearchIcon, UserIcon, HeartIcon, CartIcon, MenuIcon } from "./icons";
import AppContext, { useAppContext } from "../context/AppContext";
import MiniCart from "./mini-cart/MiniCart";
import { useRouter } from "next/router";
import MiniWish from "./mini-cart/MiniWish";

export default function Header({ children }) {
  const [isMenuShow, setIsMenuShow] = useState(false);
  const [sidenavOpen, setSidenavOpen] = useState(false);
  const [wishnavOpen, setWishnavOpen] = useState(false);

  const toggleWishnav = () => setWishnavOpen(!wishnavOpen);

  const toggleDialog = () => setDialogOpen(!dialogOpen);
  const router = useRouter();
  const { state } = useAppContext();
  const { userData, cartData, wishList } = useContext(AppContext);
  const cartTotal = state.cart.reduce(
    (sum, { price, qty }) => sum + price * qty,
    0
  );

  const toggleSidenav = () => setSidenavOpen(!sidenavOpen);

  const onViewAccountClick = () => {
    if (userData?.ref?.id) {
      router.push(`/user/profile`);
    } else {
      router.push(`/login`);
    }
  };

  console.log(cartData);
  return (
    <header className={styles.mainHeader}>
      <div className={styles.mainHeader__top}>
        <div className={styles.mainHeader__top__container}>
          <button
            className={styles.menuButton}
            onClick={() => {
              setIsMenuShow(!isMenuShow);
            }}
          >
            <MenuIcon fill="#FFFFFF" />
          </button>
          <div className={styles.topLogo}>
            <Image src={logoSymbol} alt="Logo text" width="50" height="50" />
            <div style={{ width: 16, height: 16 }}></div>
            <div className={styles.topLogo__text}>
              <Image src={logoText} alt="Logo text" width="93" />
            </div>
          </div>

          <div className={styles.topSearch}>
            <div className={styles.topSearch__content}>
              <SearchIcon fill="#9AA5B3" />
              <input
                type="text"
                placeholder="Search for products..."
                className={styles.topSearch__content__input}
              />
            </div>
            <button className={styles.topSearch__btn}>Search</button>
          </div>

          <div className={styles.topLinks}>
            <button
              className={styles.topLinks__btn}
              onClick={onViewAccountClick}
            >
              <UserIcon fill="var(--color-top-bar-icon)" />
            </button>

            <button className={styles.topLinks__btn} onClick={toggleWishnav}>
              <HeartIcon fill="var(--color-top-bar-icon)" />
              <span className={styles.topLinks__btn__count}>
                {wishList?.length ?? 0}
              </span>
            </button>

            <Drawer open={wishnavOpen} anchor="right" onClose={toggleWishnav}>
              <MiniWish />
            </Drawer>

            {/* <Link href="/cart" className={styles.topLinks__btn}>
              <span className={styles.topLinks__btn__count}>2</span>
            </Link> */}
            <Badge badgeContent={cartData?.length ?? 0} color="primary">
              <Box
                ml={2.5}
                p={0.5}
                // bgcolor="grey.200"
                component={IconButton}
                onClick={toggleSidenav}
              >
                <CartIcon fill="var(--color-top-bar-icon)" />
              </Box>
            </Badge>

            <Drawer open={sidenavOpen} anchor="right" onClose={toggleSidenav}>
              <MiniCart />
            </Drawer>

            {/* <p className={styles.topLinks__total}>${cartTotal?.toFixed(2)}</p> */}
          </div>
        </div>
      </div>

      <nav className={styles.mainHeader__nav}>
        <div
          className={styles.mainHeader__nav__container}
          style={{ left: isMenuShow === true && "0" }}
        >
          <Link href="/" className={styles.navBtn}>
            Home
          </Link>
          <Link href={"/men"} className={styles.navBtn}>
            Men
          </Link>
          <Link href={"/women"} className={styles.navBtn}>
            Women
          </Link>
          <Link href={"children"} className={styles.navBtn}>
            Children
          </Link>
          <Link href={"/about"} className={styles.navBtn}>
            About Us
          </Link>
          <Link href={"/contact"} className={styles.navBtn}>
            Contact Us
          </Link>
        </div>
      </nav>
    </header>
  );
}
