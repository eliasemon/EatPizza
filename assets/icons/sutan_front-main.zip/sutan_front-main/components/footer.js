import Image from "next/image";
import Link from "next/link";
import styles from "./styles/footer.module.scss";

import logoWhiteText from "../public/logo_white_text.svg";
import locationIco from "../public/icons/location-ico.svg";
import phoneIco from "../public/icons/phone-ico.svg";
import emailIco from "../public/icons/email-ico.svg";

import facebookIco from "../public/icons/facebook-ico.svg";
import twitterIco from "../public/icons/twitter-ico.svg";
import instagramIco from "../public/icons/instagram-ico.svg";
import youtubeIco from "../public/icons/youtube-ico.svg";

import americanExpress from "../public/payments/american_express.png";
import masterCard from "../public/payments/master_card.png";
import moovMoney from "../public/payments/moov_money.png";
import mtn from "../public/payments/mtn.png";
import orangeMoney from "../public/payments/orange_money.png";
import paypal from "../public/payments/paypal.png";
import visa from "../public/payments/visa.png";

export default function Footer({ children }) {
  return (
    <footer className={styles.mainFooter}>
      <div className={styles.mainFooter__container}>
        <div className={styles.flexColumn}>
          <div className={styles.footerLogo}>
            <Image src={logoWhiteText} alt="Logo text" width="93" />
          </div>

          <div className={styles.footerInfo}>
            <div className={styles.footerInfo__icon}>
              <Image src={locationIco} alt="Location icon" />
            </div>
            <p className={styles.footerInfo__text}>
              Lorem ipsum dolor sit consectetur, adipiscing elit.
            </p>
          </div>

          <div className={styles.footerInfo}>
            <div className={styles.footerInfo__icon}>
              <Image src={phoneIco} alt="Phone icon" />
            </div>
            <p className={styles.footerInfo__text}>+123 456 7899</p>
          </div>

          <div className={styles.footerInfo}>
            <div className={styles.footerInfo__icon}>
              <Image src={emailIco} alt="Email icon" />
            </div>
            <p className={styles.footerInfo__text}>info@sutan.com</p>
          </div>

          <div className={styles.footerInfo__socials}>
            <Link href="/" className={styles.footerInfo__socials__icon}>
              <Image src={facebookIco} alt="Facebook icon" />
            </Link>

            <Link href="/" className={styles.footerInfo__socials__icon}>
              <Image src={twitterIco} alt="Twitter icon" />
            </Link>

            <Link href="/" className={styles.footerInfo__socials__icon}>
              <Image src={instagramIco} alt="Instagram icon" />
            </Link>

            <Link href="/" className={styles.footerInfo__socials__icon}>
              <Image src={youtubeIco} alt="Youtube icon" />
            </Link>
          </div>
        </div>

        <div className={styles.flexColumn}>
          <h4 className={styles.mainFooter__title}>INFORMATION</h4>

          <Link href="/" className={styles.mainFooter__link}>
            About Us
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Contact Us
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Career
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            My Account
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Orders and Returns
          </Link>
        </div>

        <div className={styles.flexColumn}>
          <h4 className={styles.mainFooter__title}>QUICK SHOP</h4>

          <Link href="/" className={styles.mainFooter__link}>
            Men collection
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Women collection
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Children collection
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            New arrivals
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Sales products
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Popular products
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Recent view products
          </Link>
        </div>

        <div className={styles.flexColumn}>
          <h4 className={styles.mainFooter__title}>CUSTOMER SERVICES</h4>

          <Link href="/" className={styles.mainFooter__link}>
            Help & FAQs
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Returns Policy
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Terms & Conditions
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Privacy Policy
          </Link>

          <Link href="/" className={styles.mainFooter__link}>
            Support Center
          </Link>
        </div>
      </div>

      <div className={styles.mainFooter__copy}>
        <div className={styles.mainFooter__copy__container}>
          <p className={styles.mainFooter__copy__text}>
            © 2022 Sutan, all rights reserved.
          </p>
          <div className={styles.mainFooter__copy__payments}>
            <div className={styles.paymentOption}>
              <Image src={mtn} alt="mtn" />
            </div>

            <div className={styles.paymentOption}>
              <Image src={orangeMoney} alt="Orange Money" />
            </div>

            <div className={styles.paymentOption}>
              <Image src={moovMoney} alt="Moov Money" />
            </div>

            <div className={styles.paymentOption}>
              <Image src={visa} alt="Visa" />
            </div>

            <div className={styles.paymentOption}>
              <Image src={masterCard} alt="Master Card" />
            </div>

            <div className={styles.paymentOption}>
              <Image src={americanExpress} alt="American Express" />
            </div>

            <div className={styles.paymentOption}>
              <Image src={paypal} alt="Paypal" />
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
