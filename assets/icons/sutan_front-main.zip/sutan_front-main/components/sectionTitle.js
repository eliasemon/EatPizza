import styles from './styles/sectionTitle.module.scss';

export default function SectionTitle({ children }) {
    return (
        <div className={styles.sectionTitle}>
            <h3 className={styles.sectionTitle__title}>{children}</h3>
        </div>
    )
}