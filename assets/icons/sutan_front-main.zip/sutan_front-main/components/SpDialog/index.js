import { SpDialog } from "./dialogWrapper/SpDialog";
import { SpDialogHead } from "./dialogHeader/SpDialogHead";
import { SpDialogContent } from "./dialogContent/SpDialogContent";

export { SpDialogHead, SpDialogContent };

export default SpDialog;
