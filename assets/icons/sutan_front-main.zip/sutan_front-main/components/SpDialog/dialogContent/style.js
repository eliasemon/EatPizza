import styled from "styled-components";

export const DialogContent = styled.div`
  flex-grow: 3;
`;
