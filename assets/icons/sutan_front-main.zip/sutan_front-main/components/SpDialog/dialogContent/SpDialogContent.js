import React from "react";
import { DialogContent } from "./style";

export const SpDialogContent = ({ cls, sx, children }) => {
  return (
    <DialogContent className={cls} style={sx}>
      {children}
    </DialogContent>
  );
};
