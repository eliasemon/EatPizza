import React from "react";
import { Desc, DialogHead, Title } from "./style";

export const SpDialogHead = ({
  cls = "",
  title,
  desc,
  titleSx,
  sx,
  descSx,
}) => {
  return (
    <DialogHead style={sx} className={cls}>
      {title && (
        <Title style={titleSx} className={`${cls}_title`}>
          {title}
        </Title>
      )}
      {desc && (
        <Desc style={descSx} className={`${cls}_desc`}>
          {desc}
        </Desc>
      )}
    </DialogHead>
  );
};
