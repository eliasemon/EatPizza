import styles from "./styles/homeCollection.module.scss";

export default function HomeCollection(props) {
  return (
    <div className={styles.collection}>
      <div className={styles.flexColumn}>
        <h2 className={styles.collectionTitle01}>{props.title}</h2>
        <h3 className={styles.collectionTitle02}>Collection</h3>
      </div>
      <p className={styles.collectionDetails}>{props.detail}</p>
      <button className={styles.collectionBtn} onClick={props.onClick}>
        Discover
      </button>
      <img className={styles.collectionImg} src={props.img} alt={props.title} />
    </div>
  );
}
