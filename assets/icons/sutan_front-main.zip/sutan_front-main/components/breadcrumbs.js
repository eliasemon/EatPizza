import styles from './styles/breadcrumbs.module.scss';

export default function Breadcrumbs({ children }) {
  return (
    <div className={styles.breadcrumbs}>{children}</div>
  )
}