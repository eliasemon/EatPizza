/* eslint-disable react-hooks/exhaustive-deps */
import { Add, Close, Remove } from "@mui/icons-material";
import { Box, Divider } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import BazaarAvatar from "../BazaarAvatar";
import BazaarButton from "../BazaarButton";
import BazaarIconButton from "../BazaarIconButton";
import { FlexBox } from "../flex-box";
// import ShoppingBagOutlined from "../icons/ShoppingBagOutlined";
import LazyImage from "../LazyImage";
import { H5, Tiny } from "../Typography";
// import { useAppContext } from "../../contexts/AppContext";
import Link from "next/link";
import React, { useCallback, useContext } from "react"; // =========================================================
import AppContext, { useAppContext } from "../../context/AppContext";
import CartSingle from "../layouts/header/CartSingle";
import WishSingle from "../layouts/header/WishSingle";

// =========================================================
const MiniWish = () => {
  const { wishList } = useContext(AppContext);

  return (
    <Box width="380px">
      <Box
        overflow="auto"
        height={`calc(100vh - ${
          !!wishList?.length ? "80px - 3.25rem" : "0px"
        })`}
      >
        <FlexBox
          alignItems="center"
          m="0px 20px"
          height="74px"
          color="secondary.main"
        >
          {/* <ShoppingBagOutlined color="inherit" /> */}
          <Box fontWeight={600} fontSize="16px" ml={1}>
            {wishList?.length} item
          </Box>
        </FlexBox>

        <Divider />

        {!!!wishList?.length && (
          <FlexBox
            alignItems="center"
            flexDirection="column"
            justifyContent="center"
            height="calc(100% - 74px)"
          >
            <LazyImage
              src="/assets/images/logos/shopping-bag.svg"
              width={90}
              height={100}
            />
            <Box
              component="p"
              mt={2}
              color="grey.600"
              textAlign="center"
              maxWidth="200px"
            >
              Your Wish List is empty. Start shopping
            </Box>
          </FlexBox>
        )}

        {wishList.map((item) => (
          <WishSingle key={item.productRef.id} item={item} />
        ))}
      </Box>
    </Box>
  );
};

MiniWish.defaultProps = {
  toggleSidenav: () => {},
};
export default MiniWish;
