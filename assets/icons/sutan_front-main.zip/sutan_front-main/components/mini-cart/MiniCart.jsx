/* eslint-disable react-hooks/exhaustive-deps */
import { Add, Close, Remove } from "@mui/icons-material";
import { Box, Divider } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import BazaarAvatar from "../BazaarAvatar";
import BazaarButton from "../BazaarButton";
import BazaarIconButton from "../BazaarIconButton";
import { FlexBox } from "../flex-box";
// import ShoppingBagOutlined from "../icons/ShoppingBagOutlined";
import LazyImage from "../LazyImage";
import { H5, Tiny } from "../Typography";
// import { useAppContext } from "../../contexts/AppContext";
import Link from "next/link";
import React, { useCallback, useContext } from "react"; // =========================================================
import AppContext, { useAppContext } from "../../context/AppContext";
import CartSingle from "../layouts/header/CartSingle";

// =========================================================
const MiniCart = ({ toggleSidenav }) => {
  const { palette } = useTheme();
  const { state, dispatch } = useAppContext();
  const { cartData, setCartItemTotal, cartItemtotal } = useContext(AppContext);
  const cartList = state.cart;
  const handleCartAmountChange = useCallback(
    (amount, product) => () => {
      dispatch({
        type: "CHANGE_CART_AMOUNT",
        payload: { ...product, qty: amount },
      });
    },
    []
  );

  // console.log("cartItemtotal", cartItemtotal);

  const getTotalPrice = () => {
    const totals = Object.values(cartItemtotal ?? {});
    return totals?.reduce((accum, price) => accum + price, 0);
  };

  // console.log("getTotalPrice", getTotalPrice());

  return (
    <Box width="380px">
      <Box
        overflow="auto"
        height={`calc(100vh - ${
          !!cartData?.length ? "80px - 3.25rem" : "0px"
        })`}
      >
        <FlexBox
          alignItems="center"
          m="0px 20px"
          height="74px"
          color="secondary.main"
        >
          {/* <ShoppingBagOutlined color="inherit" /> */}
          <Box fontWeight={600} fontSize="16px" ml={1}>
            {cartData?.length} item
          </Box>
        </FlexBox>

        <Divider />

        {!!!cartData?.length && (
          <FlexBox
            alignItems="center"
            flexDirection="column"
            justifyContent="center"
            height="calc(100% - 74px)"
          >
            <LazyImage
              src="/assets/images/logos/shopping-bag.svg"
              width={90}
              height={100}
            />
            <Box
              component="p"
              mt={2}
              color="grey.600"
              textAlign="center"
              maxWidth="200px"
            >
              Your shopping bag is empty. Start shopping
            </Box>
          </FlexBox>
        )}

        {cartData.map((item) => (
          <CartSingle
            key={item.productRef.id}
            item={item}
            // cartItemtotal={cartItemtotal}
            setCartItemTotal={setCartItemTotal}
          />
        ))}
      </Box>

      {!!cartData.length && (
        <Box p={2.5}>
          <Link href="/checkout-alternative" passHref>
            <BazaarButton
              fullWidth
              color="primary"
              variant="contained"
              sx={{
                mb: "0.75rem",
                height: "40px",
              }}
              onClick={toggleSidenav}
            >
              Checkout Now (${getTotalPrice().toFixed(2)})
            </BazaarButton>
          </Link>

          <Link href="/cart" passHref>
            <BazaarButton
              fullWidth
              color="primary"
              variant="outlined"
              sx={{
                height: 40,
              }}
              onClick={toggleSidenav}
            >
              View Cart
            </BazaarButton>
          </Link>
        </Box>
      )}
    </Box>
  );
};

MiniCart.defaultProps = {
  toggleSidenav: () => {},
};
export default MiniCart;
