import styles from './styles/subHeader.module.scss';

export default function SubHeader({ children }) {
  return (
    <header className={styles.subHeader}>
        <h1 className={styles.subHeader__title}>{children}</h1>
    </header>
  )
}