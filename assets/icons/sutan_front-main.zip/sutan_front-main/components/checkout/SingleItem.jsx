import React, { useEffect, useMemo } from "react";
import styles from "../../styles/Checkout.module.scss";
import Image from "next/image";
import { onSnapshot } from "firebase/firestore";

const SingleItem = ({ item, setCartItemTotal, setCartItem }) => {
  const [product, setProduct] = React.useState(null);
  const [qty, setQty] = React.useState(item.quantity);

  const renderPrice = useMemo(() => {
    if (!product) return 0;
    if (product?.salePrice && product?.salePrice < product?.price) {
      return product?.salePrice;
    }
    return product?.price;
  }, [product?.salePrice, product?.price, item.productRef.id]);
  useEffect(() => {
    return onSnapshot(item.productRef, (snap) => {
      if (!snap.exists()) return;

      setProduct({
        id: snap.id,
        ...snap.data(),
        ref: snap.ref,
        path: snap.ref.path,
      });
      setCartItem((prev) => ({
        ...prev,
        [item.productRef.id]: {
          id: snap.id,
          ...snap.data(),
          ref: snap.ref,
          path: snap.ref.path,
          qty: item.quantity,
        },
      }));
    });
  }, [item.productRef.id]);

  useEffect(() => {
    setCartItemTotal((prev) => ({
      ...prev,
      [item.productRef.id]: renderPrice * qty,
    }));
  }, [qty, renderPrice]);

  return (
    <div className={styles.cart__list__item}>
      <div className={styles.cart__product}>
        <Image
          src={product?.images[0]}
          alt={product?.name ?? ""}
          objectFit="cover"
          width={80}
          height={80}
          style={{ borderRadius: 4 }}
        />
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            marginLeft: 24,
          }}
        >
          <span>{product?.name}</span>
          <span
            style={{
              color: "#444444",
              fontWeight: 500,
              padding: ".2rem 0",
            }}
          >
            Green
          </span>
          <span>x {item.quantity}</span>
        </div>
      </div>

      <div className={styles.cart__subtotal}>${renderPrice?.toFixed(2)}</div>
    </div>
  );
};

export default SingleItem;
