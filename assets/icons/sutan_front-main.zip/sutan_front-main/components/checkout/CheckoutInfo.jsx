import React from "react";
import styles from "../../styles/Checkout.module.scss";
import Image from "next/image";
import SingleItem from "./SingleItem";

const CheckoutInfo = ({
  cartData,
  getTotal,
  setCartItemTotal,
  setCartItem,
}) => {
  console.log(cartData);
  console.log(getTotal());
  return (
    <div className={styles.checkout__right}>
      <header className={styles.cart__header}>
        <div className={styles.cart__product}>Product</div>
        <div
          className={styles.cart__subtotal}
          style={{ justifyContent: "flex-end" }}
        >
          Subtotal
        </div>
      </header>

      <div className={styles.cart__list} style={{ marginBottom: 40 }}>
        {cartData?.map((item) => {
          return (
            <SingleItem
              item={item}
              key={item.productRef.id}
              setCartItemTotal={setCartItemTotal}
              setCartItem={setCartItem}
            />
          );
        })}

        <div
          className={styles.cart__list__item}
          style={{ flexDirection: "column" }}
        >
          <div
            style={{
              width: "100%",
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 10,
            }}
          >
            <span style={{ color: "#444444", fontWeight: 500 }}>Subtotal</span>
            <span>$${getTotal().toFixed(2)}</span>
          </div>
          <div
            style={{
              width: "100%",
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 10,
            }}
          >
            <span style={{ color: "#444444", fontWeight: 500 }}>Shipping</span>
            <span style={{ fontSize: "1.4rem", fontWeight: 500 }}>$0.00</span>
          </div>
          <div
            style={{
              width: "100%",
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <span style={{ color: "#444444", fontWeight: 500 }}>
              Taxes (estimated)
            </span>
            <span>$0.00</span>
          </div>
        </div>

        <div
          className={styles.cart__list__item}
          style={{ justifyContent: "space-between", border: "none" }}
        >
          <span className={styles.totalText}>Total</span>
          <span className={styles.priceText}>${getTotal().toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
};

export default CheckoutInfo;
