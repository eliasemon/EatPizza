import React, { useContext, useState } from "react";
import { CountryDropdown, RegionDropdown } from "react-country-region-selector";
import styles from "../../styles/Checkout.module.scss";
import { PrimaryButton } from "../buttons";
import { useEffect } from "react";
import { ORDERDETAILS } from "../../utils/order";
import { addDoc } from "firebase/firestore";
import { colRef } from "../../utils/services";
import { onRemoveAllFromCart } from "../../utils/cart";
import { useRouter } from "next/router";

const defaultAddress = {
  fullName: "",
  address: "",
  city: "",
  country: "United States",
  zip: "",
  apt: "",
};

const LeftSidComponent = ({
  cartData,
  getTotal,
  setCartItem,
  cartItem,
  setCartItemTotal,
  uid,
}) => {
  const [isSameAsShipping, setIsSameAsShipping] = useState(false);
  const [shipping, setShipping] = useState(defaultAddress);
  const [billing, setBilling] = useState(null);
  const [contact, setContact] = useState("");
  const [note, setNote] = useState("");
  const route = useRouter();

  const handleShippingChange = (e) => {
    setShipping({ ...shipping, [e.target.name]: e.target.value });
  };

  const handleBillingChange = (e) => {
    setBilling({ ...billing, [e.target.name]: e.target.value });
  };

  useEffect(() => {
    if (isSameAsShipping) {
      setBilling(null);
    } else {
      setBilling(defaultAddress);
    }
  }, [isSameAsShipping]);

  // const verifyInputs = () => {
  //   if (Object.values(shipping)) {

  //   }
  // }

  const onPay = async () => {
    // when paid we will create a new address if does not exist
    const products = Object.values(cartItem).map((item) => {
      let data = {
        quantity: item.qty,
        price: item.price,
        color: item?.selectedColor ?? null,
        size: item?.selectedSize ?? null,
        imgeUrl: item.images?.[0],
        productRef: item.ref,
      };
      return data;
    });
    const order = { ...ORDERDETAILS };

    order.shipping = shipping;
    order.billing = billing;
    order.contactInfo = contact;
    order.orderNote = note;
    order.products = products;
    order.total = getTotal();

    console.log(order);
    route.replace("/"); // create a new order
    addDoc(colRef(`users/${uid}/orders`), order);
    // remove all items in the cart
    onRemoveAllFromCart(uid);
    setCartItemTotal(null);
    setCartItem(null);
  };

  return (
    <div className={styles.checkout__left}>
      <div className="form">
        <h3 className="form__sectionTitle" style={{ marginTop: 0 }}>
          Contact information
        </h3>

        <div className="form__control">
          <label className="form__label">Email or mobile phone number</label>
          <input
            className="form__input"
            type="text"
            onChange={(e) => setContact(e.target.value)}
          />
        </div>

        <h3 className="form__sectionTitle">Shipping address</h3>

        <div className="flexRow">
          <div className="form__control  flexRow__col">
            <label className="form__label">Full name</label>
            <input
              className="form__input"
              type="text"
              name="fullName"
              onChange={handleShippingChange}
            />
          </div>
        </div>

        <div className="form__control">
          <label className="form__label">Country/Region</label>

          <CountryDropdown
            classes="form__input"
            value={shipping.country}
            onChange={(val) => setShipping({ ...shipping, country: val })}
          />
        </div>

        <div className="form__control">
          <label className="form__label">Address</label>
          <input
            className="form__input"
            type="text"
            name="address"
            id="address"
            onChange={handleShippingChange}
          />
        </div>

        <div className="form__control">
          <label className="form__label">
            Apartment, suite, etc. (optional)
          </label>
          <input
            className="form__input"
            type="text"
            name="apt"
            onChange={handleShippingChange}
          />
        </div>

        <div className="flexRow">
          <div className="form__control flexRow__col">
            <label className="form__label">City</label>
            {/* <input className="form__input" type="text" /> */}
            <RegionDropdown
              country={shipping.country}
              classes="form__input"
              value={shipping.city}
              onChange={(val) => setShipping({ ...shipping, city: val })}
              defaultOptionLabel="Select a city"
            />
          </div>

          <div className="form__control flexRow__col">
            <label className="form__label">Postal code</label>
            <input
              className="form__input"
              type="text"
              name="zip"
              onChange={handleShippingChange}
            />
          </div>
        </div>

        <div className="form__control">
          <label className="form__label" style={{ marginBottom: 0 }}>
            <input type="checkbox" style={{ marginRight: 8 }} />
            Save this information for next time
          </label>
        </div>

        <h3 className="form__sectionTitle" style={{ marginTop: "4rem" }}>
          Billing address
        </h3>

        <div className="form__control">
          <label className="form__label" style={{ marginBottom: 0 }}>
            <input
              type="checkbox"
              style={{ marginRight: 8 }}
              onChange={(e) => setIsSameAsShipping(e.target.checked)}
            />
            Same as shipping address
          </label>
        </div>
        {!isSameAsShipping && (
          <>
            <div className="flexRow">
              <div className="form__control flexRow__col">
                <label className="form__label">Full name</label>
                <input
                  className="form__input"
                  type="text"
                  name="fullName"
                  onChange={handleBillingChange}
                />
              </div>
            </div>

            <div className="form__control">
              <label className="form__label">Country/Region</label>
              <CountryDropdown
                classes="form__input"
                value={billing?.country ?? ""}
                onChange={(val) => setBilling({ ...billing, country: val })}
              />
            </div>

            <div className="form__control">
              <label className="form__label">Address</label>
              <input
                className="form__input"
                type="text"
                name="address"
                onChange={handleBillingChange}
              />
            </div>

            <div className="form__control">
              <label className="form__label">
                Apartment, suite, etc. (optional)
              </label>
              <input
                className="form__input"
                type="text"
                name="apt"
                onChange={handleBillingChange}
              />
            </div>

            <div className="flexRow">
              <div className="form__control flexRow__col">
                <label className="form__label">City</label>
                <RegionDropdown
                  country={billing?.country ?? ""}
                  classes="form__input"
                  value={billing?.city ?? ""}
                  onChange={(val) => setBilling({ ...billing, city: val })}
                  defaultOptionLabel="Select a city"
                />
              </div>

              <div className="form__control flexRow__col">
                <label className="form__label">Postal code</label>
                <input
                  className="form__input"
                  type="text"
                  name="zip"
                  onChange={handleBillingChange}
                />
              </div>
            </div>
          </>
        )}

        <h3 className="form__sectionTitle">Payment method</h3>

        <div className="form__control">
          <label
            className="form__label"
            style={{
              marginBottom: 0,
              fontSize: 18,
              fontWeight: 600,
              color: "#000000",
            }}
          >
            <input type="radio" style={{ marginRight: 12 }} />
            Debit / Credit Card
          </label>
        </div>

        <div style={{ marginLeft: 30 }}>
          <div className="form__control">
            <label className="form__label">Enter card number</label>
            <input className="form__input" type="text" />
          </div>

          <div className="flexRow">
            <div className="form__control flexRow__col">
              <label className="form__label">Valid Date</label>
              <div
                className="flexRow"
                style={{
                  backgroundColor: "#ffffff",
                  borderRadius: 4,
                  paddingLeft: 16,
                  paddingRight: 16,
                }}
              >
                <div
                  className="form__control flexRow__col"
                  style={{ marginBottom: 0 }}
                >
                  <select className="form__input">
                    <option>MM</option>
                  </select>
                </div>
                <div
                  className="form__control flexRow__col"
                  style={{ marginBottom: 0 }}
                >
                  <select className="form__input">
                    <option>YYYY</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="form__control flexRow__col">
              <label className="form__label">CVV</label>
              <input className="form__input" type="text" />
            </div>
          </div>
        </div>

        <div className="form__control">
          <label
            className="form__label"
            style={{
              marginBottom: 0,
              fontSize: 18,
              fontWeight: 600,
              color: "#000000",
            }}
          >
            <input type="radio" style={{ marginRight: 12 }} />
            Net Banking
          </label>
        </div>

        <div className="form__control">
          <label
            className="form__label"
            style={{
              marginBottom: 0,
              fontSize: 18,
              fontWeight: 600,
              color: "#000000",
            }}
          >
            <input type="radio" style={{ marginRight: 12 }} />
            Google / Apple Wallet
          </label>
        </div>

        <div className="form__control">
          <h3 className="text-3xl font-bold mb-5">Order Note</h3>
          <textarea
            className="w-full h-auto border border-gray-300 rounded-md p-2 outline-red-900"
            type="text"
            placeholder="Add note for your order"
            rows={10}
            onChange={(e) => setNote(e.target.value)}
          />
        </div>

        <div
          className="flexRow"
          style={{ justifyContent: "flex-end", marginBottom: "4rem" }}
        >
          <PrimaryButton
            title={`Pay $${getTotal().toFixed(2)}`}
            style={{ padding: "0 5.2rem" }}
            onClick={onPay}
          />
        </div>
      </div>
    </div>
  );
};

export default LeftSidComponent;
