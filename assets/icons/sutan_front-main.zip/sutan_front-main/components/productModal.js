import React, { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import styles from "./styles/productModal.module.scss";
import ProductQuantity from "./productQuantity";
import Image from "next/image";
import HtmlReactParser from "html-react-parser";
import { BlackButton } from "./buttons";
import { CloseIcon, RightArrowIcon, LeftArrowIcon } from "./icons";
import availabilIco from "./../public/icons/available-ico.svg";

const ProductModal = ({ show, onClose, product }) => {
  const [productColor, setProductColor] = useState("color1");
  const [productPic, setProductPic] = useState("pic01");
  const [isBrowser, setIsBrowser] = useState(false);
  const [viewingIndex, setViewingIndex] = useState(0);

  const [productVariant, setProductVariant] = useState({});
  const [selVariant, setSelVariant] = useState([]);
  const [selTab, setSelTab] = useState("description");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [hasVariants, setHasVariants] = useState(false);
  const [isSeletedVariantInStock, setIsSeletedVariantInStock] = useState(false);
  // const [canAddToCart, setCanAddToCart] = useState(false);
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [requiredAttributes, setRequiredAttributes] = useState([]);

  const stockStatus = product?.stockStatus === "IN_STOCK";

  const allImages = [product?.image, ...product?.galleryImages?.nodes];
  console.log("product", product);

  useEffect(() => {
    if (hasVariants) {
      const result = product?.variations?.nodes.filter((variation) => {
        return selVariant.every((attribute) => {
          return variation.attributes.nodes.some((variationAttribute) => {
            return (
              attribute.label.toLowerCase() ===
                variationAttribute.label.toLowerCase() &&
              attribute.value.toLowerCase() ===
                variationAttribute.value.toLowerCase()
            );
          });
        });
      });
      setSelectedVariant(result);

      console.log("filteredVariant", result);
    }

    // get the selected variant based on productVariant
  }, [selVariant, productVariant]);

  const renderUniqueVariants = useMemo(() => {
    const uniqueAttributes = new Set();
    product?.variations?.nodes.forEach((variation) => {
      variation.attributes.nodes.forEach((attribute) => {
        uniqueAttributes.add(attribute.label);
      });
    });

    if (uniqueAttributes.size > 0) {
      setHasVariants(true);
    }

    setRequiredAttributes(uniqueAttributes);

    // use the unique set of attributes to render the attributes
    const attributes = product?.attributes?.nodes.filter((attribute) =>
      uniqueAttributes.has(attribute.name)
    );

    return attributes || [];
  }, [product]);

  const addVariant = (attribute) => {
    // check if attribut label is already in selVariant array
    // if yes, replace it with the new attribute
    // if no, add it to the array
    const isAttributeInArray = selVariant.find(
      (variant) => variant.label === attribute.label
    );

    if (isAttributeInArray) {
      const newSelVariant = selVariant.map((variant) => {
        if (variant.label === attribute.label) {
          return attribute;
        } else {
          return variant;
        }
      });

      setSelVariant(newSelVariant);
    } else {
      setSelVariant([...selVariant, attribute]);
    }
  };

  const renderAttributes = () => {
    return renderUniqueVariants?.map((attribute) => {
      return (
        <div
          className={styles.product__attributes__attribute}
          key={attribute.id}
        >
          <h3 className={styles.product__attributes__attribute__title}>
            {attribute.name}
          </h3>
          <div className={styles.product__attributes__attribute__options}>
            {attribute?.options?.map((option) => {
              return (
                <div
                  className={
                    styles.product__attributes__attribute__options__option
                  }
                  key={option}
                >
                  <input
                    type="radio"
                    name={attribute.name}
                    id={option}
                    value={option}
                    // checked={productColor === option}
                    checked={productVariant[attribute.name] === option}
                    onChange={() => {
                      setProductVariant({
                        ...productVariant,
                        [attribute.name]: option,
                      });
                      addVariant({ label: attribute.name, value: option });
                    }}
                  />
                  <label htmlFor={option}>{option}</label>
                </div>
              );
            })}
          </div>
        </div>
      );
    });
  };

  // console.log("productVariant", productVariant);
  // console.log("uniqueAttributes", uniqueAttributes);
  console.log("isSeletedVariantInStock", isSeletedVariantInStock);

  const canAddToCart = useMemo(() => {
    if (hasVariants) {
      return (
        selectedVariant?.length === 1 &&
        selectedVariant?.[0]?.stockStatus === "IN_STOCK"
      );
    }
    return stockStatus;
  }, [hasVariants, selectedVariant, isSeletedVariantInStock, stockStatus]);

  console.log("canAddToCart", canAddToCart);

  useEffect(() => {
    setIsBrowser(true);
  }, []);

  const handleCloseClick = (event) => {
    event.preventDefault();
    onClose();
  };

  const handleNextClick = () => {
    if (viewingIndex < allImages?.length - 1) {
      setViewingIndex(viewingIndex + 1);
    }
  };

  const handlePrevClick = () => {
    if (viewingIndex > 0) {
      setViewingIndex(viewingIndex - 1);
    }
  };

  const goTo = (index) => {
    setViewingIndex(index);
  };

  // console.log(product?.images);

  const renderPrice = () => {
    if (product?.salePrice) {
      return product?.salePrice;
    } else {
      return product?.price;
    }
  };

  const modalContent = show ? (
    <div className={styles.modalBg}>
      <div className={styles.productModal}>
        <section className={styles.product}>
          <button className={styles.closeBtn} onClick={handleCloseClick}>
            <CloseIcon fill="#000000" />
          </button>

          <div className={styles.product__slide}>
            <button className={styles.rightArrowBtn} onClick={handleNextClick}>
              <RightArrowIcon fill="#000000" />
            </button>
            <button className={styles.leftArrowBtn} onClick={handlePrevClick}>
              <LeftArrowIcon fill="#000000" />
            </button>
            <img
              className={styles.product__slide__img}
              src={allImages?.[viewingIndex]?.sourceUrl}
              alt="pic"
            />

            <div className={styles.productThumbs}>
              {allImages?.map((image, index) => {
                return (
                  <label
                    className={styles.productThumbs__item}
                    key={index}
                    htmlFor={`pic-0${index + 1}`}
                    style={{
                      borderColor: viewingIndex === index && "#000000",
                    }}
                  >
                    <Image
                      src={image?.sourceUrl}
                      objectFit="cover"
                      alt={`${product?.name}-${index}`}
                      width={56}
                      height={56}
                      style={{ borderRadius: 2 }}
                    />
                    <input
                      type="radio"
                      className={styles.productThumbs__item__input}
                      name={product?.name}
                      id={`pic-0${index + 1}`}
                      onChange={() => {
                        setProductPic(`pic-0${index + 1}`);
                        goTo(index);
                      }}
                    />
                  </label>
                );
              })}
            </div>
          </div>

          <div className={styles.product__detail}>
            <h1 className={styles.productTitle}>{product?.name}</h1>

            <div className={styles.availability} style={{ color: "#0F834D" }}>
              <Image
                src={availabilIco}
                alt="Availabil Ico"
                width="14"
                height="14"
              />
              <span style={{ marginLeft: 6 }}>In Stock</span>
            </div>

            <h2 className={styles.productPrice}>{renderPrice()}</h2>

            <div>{HtmlReactParser(product?.shortDescription)}</div>

            {renderAttributes()}

            {/* <div className={styles.labelTitle}>
              Color:<span className={styles.labelTitle__value}>Green</span>
            </div> */}

            {/* <div className={styles.productColors}>
              <label
                className={styles.productColors__item}
                htmlFor="color-01"
                style={{ borderColor: productColor === "color1" && "#000000" }}
              >
                <Image
                  src="/product_pic01.png"
                  objectFit="cover"
                  width={44}
                  height={44}
                  style={{ borderRadius: 2 }}
                />
                <input
                  type="radio"
                  className={styles.productColors__item__input}
                  name="phone_color"
                  id="color-01"
                  onChange={() => {
                    setProductColor("color1");
                  }}
                />
              </label>

              <label
                className={styles.productColors__item}
                htmlFor="color-02"
                style={{ borderColor: productColor === "color2" && "#000000" }}
              >
                <Image
                  src="/product_pic01.png"
                  objectFit="cover"
                  width={44}
                  height={44}
                  style={{ borderRadius: 2 }}
                />
                <input
                  type="radio"
                  className={styles.productColors__item__input}
                  name="phone_color"
                  id="color-02"
                  onChange={() => {
                    setProductColor("color2");
                  }}
                />
              </label>

              <label
                className={styles.productColors__item}
                htmlFor="color-03"
                style={{ borderColor: productColor === "color3" && "#000000" }}
              >
                <Image
                  src="/product_pic01.png"
                  objectFit="cover"
                  width={44}
                  height={44}
                  style={{ borderRadius: 2 }}
                />
                <input
                  type="radio"
                  className={styles.productColors__item__input}
                  name="phone_color"
                  id="color-03"
                  onChange={() => {
                    setProductColor("color3");
                  }}
                />
              </label>
            </div> */}

            <div className={styles.labelTitle}>Quantity:</div>

            <div className={styles.productQuantity}>
              <div style={{ marginBottom: 16 }}>
                <ProductQuantity quantity={1} />
              </div>

              <BlackButton
                title="Add to cart"
                style={{ width: 256 }}
                disabled={!canAddToCart}
              />
            </div>
          </div>
        </section>
      </div>
    </div>
  ) : null;

  if (isBrowser) {
    return createPortal(modalContent, document.getElementById("modal-root"));
  } else {
    return null;
  }
};

export default ProductModal;
