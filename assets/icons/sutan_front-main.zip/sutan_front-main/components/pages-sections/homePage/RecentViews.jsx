import { useRouter } from "next/router";
import styles from "../../../styles/Home.module.scss";
import React from "react";
import SectionTitle from "../../sectionTitle";
import ProductCard from "../../productCard";

const RecentViews = () => {
  return (
    <>
      <SectionTitle>
        Recent View <strong>Products</strong>
      </SectionTitle>
      <div className={styles.products}>
        <div className={styles.products__container}>
          <ProductCard
            title="Linen-blend Shirt"
            price="$15.00"
            prevPrice="$17.00"
            rating="5"
            totalRating="11"
            img="./../product_pic01.png"
          />
          <ProductCard
            title="Boxy Denim Jacket"
            price="$20.00"
            prevPrice="$25.00"
            rating="3"
            totalRating="24"
            img="./../product_pic01.png"
          />
          <ProductCard
            title="Denim Jacket"
            price="$13.00"
            prevPrice="$16.00"
            img="./../product_pic01.png"
          />
          <ProductCard
            title="High Ankle Jeans"
            price="$18.00"
            prevPrice="$21.00"
            rating="4"
            totalRating="7"
            img="./../product_pic01.png"
          />
        </div>
      </div>
    </>
  );
};

export default RecentViews;
