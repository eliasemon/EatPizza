import { useRouter } from "next/router";
import styles from "../../../styles/Home.module.scss";
import React from "react";
import SectionTitle from "../../sectionTitle";
import ProductCard from "../../productCard";

const Populars = ({ products }) => {
  return (
    <>
      <SectionTitle>
        Popular <strong>Products</strong>
      </SectionTitle>
      <div className={styles.products}>
        <div className={styles.products__container}>
          {products.map((product, index) => {
            return <ProductCard key={index} product={product} />;
          })}
        </div>
      </div>
    </>
  );
};

export default Populars;
