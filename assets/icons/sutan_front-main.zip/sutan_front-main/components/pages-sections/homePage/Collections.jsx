import { useRouter } from "next/router";

import React from "react";
import styles from "../../../styles/Home.module.scss";
import HomeCollection from "../../homeCollection";

const CollectionsComponent = () => {
  const router = useRouter();
  return (
    <div className={styles.collections}>
      <div className={styles.collections__container}>
        <HomeCollection
          title="Men"
          detail="Lorem ipsum dolor amet, consectetur elit."
          img="./../men_collections.png"
          onClick={() => router.push("/men")}
        />
        <HomeCollection
          title="Children"
          detail="Lorem ipsum dolor amet, consectetur elit."
          img="./../children_collecttions.png"
          onClick={() => router.push("/children")}
        />
        <HomeCollection
          title="Women"
          detail="Lorem ipsum dolor amet, consectetur elit."
          img="./../women_collections.png"
          onClick={() => router.push("/women")}
        />
      </div>
    </div>
  );
};

export default CollectionsComponent;
