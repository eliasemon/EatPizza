import styles from "./styles/buttons.module.scss";

export const BlackButton = (props) => {
  return (
    <button
      className={styles.blackBtn}
      style={props.style}
      onClick={props.onClick}
      disabled={props.disabled}
    >
      {props.title}
    </button>
  );
};

export const PrimaryButton = (props) => {
  return (
    <button
      className={styles.primaryBtn}
      style={props.style}
      onClick={props.onClick}
    >
      {props.title}
    </button>
  );
};

export const SecondaryButton = (props) => {
  return (
    <button
      className={styles.secondaryBtn}
      style={props.style}
      onClick={props.onClick}
      disabled={props.disabled}
    >
      {props.title}
    </button>
  );
};

export const BlackOutlineButton = (props) => {
  return (
    <button
      className={styles.blackOutlineBtn}
      style={props.style}
      onClick={props.onClick}
    >
      {props.title}
    </button>
  );
};
