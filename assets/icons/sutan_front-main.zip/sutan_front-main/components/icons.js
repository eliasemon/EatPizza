export const UserIcon = (props) => (
    <svg width="22" height="24" viewBox="0 0 22 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10.6199 10.1953C13.182 10.1953 15.259 8.1183 15.259 5.55616C15.259 2.99402 13.182 0.916992 10.6199 0.916992C8.05774 0.916992 5.98071 2.99402 5.98071 5.55616C5.98071 8.1183 8.05774 10.1953 10.6199 10.1953Z" stroke={props.fill} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M1.24658 23.0837V20.4396C1.24658 17.3521 3.74826 14.8662 6.81992 14.8662H15.1641C18.2516 14.8662 20.7374 17.3679 20.7374 20.4396V23.0837" stroke={props.fill} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const HeartIcon = (props) => (
    <svg width="28" height="24" viewBox="0 0 28 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M26.3334 7.62647C26.3334 9.17313 25.7467 10.7331 24.5601 11.9198L22.5868 13.8931L14.0934 22.3865C14.0534 22.4265 14.0401 22.4398 14.0001 22.4665C13.9601 22.4398 13.9467 22.4265 13.9067 22.3865L3.44008 11.9198C2.25342 10.7331 1.66675 9.18647 1.66675 7.62647C1.66675 6.06647 2.25342 4.50647 3.44008 3.3198C5.81342 0.959805 9.65341 0.959805 12.0267 3.3198L13.9867 5.29313L15.9601 3.3198C18.3334 0.959805 22.1601 0.959805 24.5334 3.3198C25.7467 4.50647 26.3334 6.05313 26.3334 7.62647Z" stroke={props.fill} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const CartIcon = (props) => (
    <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10.1065 26.3339C10.9607 26.3339 11.6531 25.6354 11.6531 24.7739C11.6531 23.9123 10.9607 23.2139 10.1065 23.2139C9.25228 23.2139 8.55981 23.9123 8.55981 24.7739C8.55981 25.6354 9.25228 26.3339 10.1065 26.3339Z" stroke={props.fill} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M20.5999 26.3339C21.4541 26.3339 22.1466 25.6354 22.1466 24.7739C22.1466 23.9123 21.4541 23.2139 20.5999 23.2139C19.7457 23.2139 19.0532 23.9123 19.0532 24.7739C19.0532 25.6354 19.7457 26.3339 20.5999 26.3339Z" stroke={props.fill} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M22.6001 18.5605H8.89345C8.17345 18.5605 7.54678 18.0538 7.38678 17.3338L5.36011 8.01379C5.14678 7.04046 5.88011 6.13379 6.86678 6.13379H24.6268C25.6134 6.13379 26.3468 7.05379 26.1334 8.01379L24.1068 17.3338C23.9601 18.0538 23.3334 18.5605 22.6001 18.5605Z" stroke={props.fill} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M1.66675 1.66699H2.77341C3.50675 1.66699 4.13341 2.17366 4.28008 2.88033L5.52008 8.66699" stroke={props.fill} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M21.1332 18.5605H7.22656C6.1199 18.5605 5.22656 19.4539 5.22656 20.5605C5.22656 21.6672 6.1199 22.5605 7.22656 22.5605H23.9066" stroke={props.fill} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const SearchIcon = (props) => (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M8.1415 14.992C4.35817 14.992 1.2915 11.9253 1.2915 8.14199C1.2915 4.35866 4.35817 1.29199 8.1415 1.29199C11.9248 1.29199 14.9915 4.35866 14.9915 8.14199C14.9915 11.9253 11.9248 14.992 8.1415 14.992Z" stroke={props.fill} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M16.7082 16.7092L13.2832 13.2842" stroke={props.fill} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const MenuIcon = (props) => (
    <svg width="27" height="25" viewBox="0 0 27 25" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M0 1.5C0 0.671573 0.619913 0 1.38462 0H25.6154C26.3801 0 27 0.671573 27 1.5C27 2.32843 26.3801 3 25.6154 3H1.38462C0.619913 3 0 2.32843 0 1.5Z" fill={props.fill} />
        <path fill-rule="evenodd" clip-rule="evenodd" d="M0 23.5C0 22.6716 0.619913 22 1.38462 22H25.6154C26.3801 22 27 22.6716 27 23.5C27 24.3284 26.3801 25 25.6154 25H1.38462C0.619913 25 0 24.3284 0 23.5Z" fill={props.fill} />
        <path fill-rule="evenodd" clip-rule="evenodd" d="M0 12.5C0 11.6716 0.619913 11 1.38462 11H25.6154C26.3801 11 27 11.6716 27 12.5C27 13.3284 26.3801 14 25.6154 14H1.38462C0.619913 14 0 13.3284 0 12.5Z" fill={props.fill} />
    </svg>
);

export const EyeIcon = (props) => (
    <svg width="22" height="18" viewBox="0 0 22 18" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M19.8834 5.76061C21.4001 7.59144 21.4001 10.4081 19.8834 12.2389C17.7168 14.8498 14.5426 16.5181 11.0001 16.5181C7.45759 16.5181 4.29425 14.8606 2.11675 12.2389C0.600081 10.4081 0.600081 7.59144 2.11675 5.76061C4.28341 3.14978 7.45759 1.48145 11.0001 1.48145C14.5426 1.48145 17.7059 3.13894 19.8834 5.76061Z" stroke={props.fill} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M11.0002 12.3364C12.843 12.3364 14.3369 10.8425 14.3369 8.99975C14.3369 7.15696 12.843 5.66309 11.0002 5.66309C9.15744 5.66309 7.66357 7.15696 7.66357 8.99975C7.66357 10.8425 9.15744 12.3364 11.0002 12.3364Z" stroke={props.fill} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const CloseIcon = (props) => (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M13 0.910156L1 13.0901" stroke={props.fill} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M1 0.910156L13 13.0901" stroke={props.fill} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const RightArrowIcon = (props) => (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M6.81566 0.190906L6.19694 0.809625C6.0505 0.956063 6.0505 1.1935 6.19694 1.33997L11.0448 6.18775H0.375C0.167906 6.18775 0 6.35566 0 6.56275V7.43775C0 7.64484 0.167906 7.81275 0.375 7.81275H11.0448L6.19694 12.6606C6.0505 12.807 6.0505 13.0444 6.19694 13.1909L6.81566 13.8096C6.96209 13.9561 7.19953 13.9561 7.346 13.8096L13.8902 7.26544C14.0366 7.119 14.0366 6.88156 13.8902 6.73509L7.34597 0.190906C7.19953 0.0444375 6.96209 0.0444375 6.81566 0.190906Z" fill={props.fill} />
    </svg>
);

export const LeftArrowIcon = (props) => (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M8.18434 14.8091L8.80306 14.1904C8.9495 14.0439 8.9495 13.8065 8.80306 13.66L3.95525 8.81225L14.625 8.81225C14.8321 8.81225 15 8.64434 15 8.43725L15 7.56225C15 7.35516 14.8321 7.18725 14.625 7.18725L3.95525 7.18725L8.80306 2.33944C8.9495 2.193 8.9495 1.95556 8.80306 1.80909L8.18435 1.19037C8.03791 1.04394 7.80047 1.04394 7.654 1.19037L1.10981 7.73456C0.963376 7.881 0.963376 8.11844 1.10981 8.2649L7.65403 14.8091C7.80047 14.9556 8.03791 14.9556 8.18434 14.8091Z" fill={props.fill} />
    </svg>
);